#!/usr/bin/env python3
"""
generate_pdf.py
===============
Converts report.md into a publication-grade, professionally formatted PDF report
for INT315 - Cluster Computing using markdown-it-py, pygments, KaTeX, and Google Chrome Headless.
"""

import os
import sys
import re
import base64
import subprocess
import markdown_it
from pygments import highlight
from pygments.lexers import get_lexer_by_name, TextLexer
from pygments.formatters import HtmlFormatter

WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))
REPORT_MD_PATH = os.path.join(WORKSPACE_DIR, "report.md")
REPORT_HTML_PATH = os.path.join(WORKSPACE_DIR, "report.html")
OUTPUT_PDF_PATH = os.path.join(WORKSPACE_DIR, "Project_15_Bus_Route_Optimization_Report.pdf")
NETWORK_PNG_PATH = os.path.join(WORKSPACE_DIR, "viz", "network.png")

def get_base64_image(path):
    if os.path.exists(path):
        with open(path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")
            return f"data:image/png;base64,{b64}"
    return ""

def highlight_code(code, lang, attrs):
    try:
        if not lang:
            lexer = TextLexer()
        else:
            lang_clean = lang.strip().lower()
            if lang_clean in ("scala", "spark"):
                lexer = get_lexer_by_name("scala")
            elif lang_clean in ("python", "py"):
                lexer = get_lexer_by_name("python")
            elif lang_clean in ("bash", "sh", "zsh", "shell"):
                lexer = get_lexer_by_name("bash")
            elif lang_clean in ("json",):
                lexer = get_lexer_by_name("json")
            elif lang_clean in ("csv",):
                lexer = TextLexer()
            else:
                lexer = get_lexer_by_name(lang_clean)
    except Exception:
        lexer = TextLexer()
    formatter = HtmlFormatter(nowrap=False, style="friendly")
    return highlight(code, lexer, formatter)

def transform_screenshot_placeholders(content):
    """
    Replaces raw [INSERT SCREENSHOT HERE] and preceding markdown captions with
    styled, structured screenshot cards with dedicated frames.
    """
    
    # 8.1 Preprocessing Execution
    pattern_8_1 = re.compile(
        r"### 8\.1 Preprocessing Execution\s*\n\*Screenshot:[^\n]+\*\s*\n+```\s*\n\[INSERT SCREENSHOT HERE\]\s*\n```(\s*\n*<br\s*\/?>)*",
        re.MULTILINE
    )
    card_8_1 = """### 8.1 Preprocessing Execution
<div class="screenshot-card">
  <div class="sc-header">
    <div class="sc-badge">Screenshot 1 / 5 &bull; Execution</div>
    <div class="sc-title">Preprocessing Execution Terminal Output</div>
  </div>
  <div class="sc-body">
    <div class="sc-placeholder">
      <div class="sc-icon">
        <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
          <line x1="8" y1="21" x2="16" y2="21"></line>
          <line x1="12" y1="17" x2="12" y2="21"></line>
        </svg>
      </div>
      <div class="sc-prompt">[ ATTACH SCREENSHOT HERE ]</div>
      <div class="sc-detail">Terminal output executing <code>python preprocess_gtfs.py</code> demonstrating GTFS extraction, trip sequencing, stop deduplication, Haversine road calculation, and generation of <code>data/stops.csv</code> &amp; <code>data/edges.csv</code>.</div>
    </div>
  </div>
</div>
"""
    content = pattern_8_1.sub(card_8_1, content)

    # 8.2 Spark Shell Graph Construction
    pattern_8_2 = re.compile(
        r"### 8\.2 Spark Shell — Graph Construction\s*\n\*Screenshot:[^\n]+\*\s*\n+```\s*\n\[INSERT SCREENSHOT HERE\]\s*\n```(\s*\n*<br\s*\/?>)*",
        re.MULTILINE
    )
    card_8_2 = """### 8.2 Spark Shell — Graph Construction
<div class="screenshot-card">
  <div class="sc-header">
    <div class="sc-badge">Screenshot 2 / 5 &bull; Execution</div>
    <div class="sc-title">Spark Shell Graph Construction (Steps 1 &ndash; 2)</div>
  </div>
  <div class="sc-body">
    <div class="sc-placeholder">
      <div class="sc-icon">
        <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <path d="M4 17l6-6-6-6"></path>
          <line x1="12" y1="19" x2="20" y2="19"></line>
        </svg>
      </div>
      <div class="sc-prompt">[ ATTACH SCREENSHOT HERE ]</div>
      <div class="sc-detail">Terminal executing <code>spark-shell --master "local[*]"</code> and <code>:load BusRoute.scala</code> showing Spark initialization, CSV parsing into VertexRDD/EdgeRDD, and initial graph construction (8,374 vertices and 8,284 directed edges).</div>
    </div>
  </div>
</div>
"""
    content = pattern_8_2.sub(card_8_2, content)

    # 8.3 Centrality & Pregel SSSP
    pattern_8_3 = re.compile(
        r"### 8\.3 Spark Shell — Centrality & Pregel SSSP Execution\s*\n\*Screenshot:[^\n]+\*\s*\n+```\s*\n\[INSERT SCREENSHOT HERE\]\s*\n```(\s*\n*<br\s*\/?>)*",
        re.MULTILINE
    )
    card_8_3 = """### 8.3 Spark Shell — Centrality & Pregel SSSP Execution
<div class="screenshot-card">
  <div class="sc-header">
    <div class="sc-badge">Screenshot 3 / 5 &bull; Execution</div>
    <div class="sc-title">Degree Centrality &amp; Pregel SSSP Supersteps (Steps 3 &ndash; 7)</div>
  </div>
  <div class="sc-body">
    <div class="sc-placeholder">
      <div class="sc-icon">
        <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <polyline points="12 6 12 12 16 14"></polyline>
        </svg>
      </div>
      <div class="sc-prompt">[ ATTACH SCREENSHOT HERE ]</div>
      <div class="sc-detail">Spark Shell output displaying Degree Centrality rankings (Super Bazar, Dhaula Kuan), iterative Pregel BSP superstep messages, and shortest path outputs before and after Route 9999 optimization.</div>
    </div>
  </div>
</div>
"""
    content = pattern_8_3.sub(card_8_3, content)

    # 9.2 Interactive Web Map
    pattern_9_2 = re.compile(
        r"### 9\.2 Interactive Web Map \(`viz\/map\.html`\)\s*\n\*Screenshot:[^\n]+\*\s*\n+```\s*\n\[INSERT SCREENSHOT HERE\]\s*\n```(\s*\n*<br\s*\/?>)*",
        re.MULTILINE
    )
    card_9_2 = """### 9.2 Interactive Web Map (`viz/map.html`)
<div class="screenshot-card">
  <div class="sc-header">
    <div class="sc-badge">Screenshot 4 / 5 &bull; Result</div>
    <div class="sc-title">Interactive Geographic Map View (Folium / OpenStreetMap)</div>
  </div>
  <div class="sc-body">
    <div class="sc-placeholder">
      <div class="sc-icon">
        <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"></polygon>
          <line x1="8" y1="2" x2="8" y2="18"></line>
          <line x1="16" y1="6" x2="16" y2="22"></line>
        </svg>
      </div>
      <div class="sc-prompt">[ ATTACH SCREENSHOT HERE ]</div>
      <div class="sc-detail">Web browser rendering <code>viz/map.html</code> showing interactive bus stops, route lines, 25-hop circuitous detour corridor (red), and proposed direct express Route 9999 (green) across the Delhi National Capital Region.</div>
    </div>
  </div>
</div>
"""
    content = pattern_9_2.sub(card_9_2, content)

    # 9.3 Output CSV Files
    pattern_9_3 = re.compile(
        r"### 9\.3 Generated Output CSV Files\s*\n\*Screenshot:[^\n]+\*\s*\n+```\s*\n\[INSERT SCREENSHOT HERE\]\s*\n```(\s*\n*<br\s*\/?>)*",
        re.MULTILINE
    )
    card_9_3 = """### 9.3 Generated Output CSV Files
<div class="screenshot-card">
  <div class="sc-header">
    <div class="sc-badge">Screenshot 5 / 5 &bull; Result</div>
    <div class="sc-title">Generated Output Artifacts (Directory Listing)</div>
  </div>
  <div class="sc-body">
    <div class="sc-placeholder">
      <div class="sc-icon">
        <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
        </svg>
      </div>
      <div class="sc-prompt">[ ATTACH SCREENSHOT HERE ]</div>
      <div class="sc-detail">Terminal or Finder screenshot showing the contents of the <code>output/</code> directory: <code>centrality.csv</code>, <code>path_before.csv</code>, <code>path_after.csv</code>, and <code>new_edge.csv</code>.</div>
    </div>
  </div>
</div>
"""
    content = pattern_9_3.sub(card_9_3, content)

    # Clean up any remaining multiple <br/> tags
    content = re.sub(r"(<br\s*\/?>\s*){2,}", "", content)

    return content

def build_html_report():
    with open(REPORT_MD_PATH, "r", encoding="utf-8") as f:
        md_text = f.read()

    # Strip duplicate top markdown metadata (already rendered in executive doc-header)
    md_text = re.sub(r"^# Project 15:.*?\n\s*---\s*\n*", "", md_text, count=1, flags=re.DOTALL)

    # Pre-process screenshot placeholders
    md_text = transform_screenshot_placeholders(md_text)

    # Replace network.png with base64 embedded version
    img_b64 = get_base64_image(NETWORK_PNG_PATH)
    if img_b64:
        img_html = f'''<div class="figure-container">
  <img src="{img_b64}" alt="Delhi Bus Route Network Optimization — Before vs. After" class="network-figure" />
  <div class="figure-caption"><strong>Figure 1:</strong> Delhi Bus Route Network Optimization — Spatial visualization of the 8,374-node DTC network comparing the 25-hop, 18.88 km circuitous path (Before) against the 1-hop, 9.57 km direct express corridor (After) generated by <code>viz/plot.py</code>.</div>
</div>'''
        md_text = re.sub(r"!\[Delhi Bus Route Network Optimization — Before vs\. After\]\(viz\/network\.png\)", img_html, md_text)

    # Setup Markdown parser
    md = markdown_it.MarkdownIt("gfm-like", {"linkify": False, "highlight": highlight_code})
    html_body = md.render(md_text)

    # Pygments CSS
    formatter = HtmlFormatter(style="friendly")
    pygments_css = formatter.get_style_defs(".highlight")

    # Complete styled HTML template
    full_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Project 15: Bus Route Optimization using Apache Spark GraphX</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/contrib/auto-render.min.js"
    onload="renderMathInElement(document.body, {{delimiters: [{{left: '$$', right: '$$', display: true}}, {{left: '$', right: '$', display: false}}]}});">
</script>

<style>
/* ==================== GLOBAL STYLES & TYPOGRAPHY ==================== */
@page {{
    size: A4 portrait;
    margin: 18mm 16mm 20mm 16mm;
    @bottom-center {{
        content: counter(page);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 8.5pt;
        color: #64748b;
    }}
}}

*, *:before, *:after {{
    box-sizing: border-box;
}}

body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 10pt;
    line-height: 1.62;
    color: #1e293b;
    background: #ffffff;
    margin: 0;
    padding: 0;
}}

/* ==================== COVER & HEADER BLOCK ==================== */
.doc-header {{
    border-bottom: 2.5px solid #1e3a8a;
    padding-bottom: 18px;
    margin-bottom: 26px;
}}

.doc-course-tag {{
    display: inline-block;
    background: #1e3a8a;
    color: #ffffff;
    font-size: 8.5pt;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    padding: 3px 10px;
    border-radius: 4px;
    margin-bottom: 12px;
}}

.doc-main-title {{
    font-size: 22pt;
    font-weight: 800;
    color: #0f172a;
    line-height: 1.25;
    margin: 0 0 8px 0;
    letter-spacing: -0.02em;
}}

.doc-subtitle {{
    font-size: 12pt;
    font-weight: 500;
    color: #3b82f6;
    margin: 0 0 16px 0;
}}

.doc-meta-grid {{
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 12px 16px;
    margin-top: 14px;
}}

.meta-item {{
    font-size: 8.5pt;
}}

.meta-label {{
    color: #64748b;
    text-transform: uppercase;
    font-size: 7pt;
    font-weight: 700;
    letter-spacing: 0.05em;
    margin-bottom: 2px;
}}

.meta-val {{
    color: #0f172a;
    font-weight: 600;
}}

/* ==================== HEADINGS & SECTIONS ==================== */
h1 {{
    display: none; /* replaced by custom doc-header */
}}

h2 {{
    font-size: 13.5pt;
    font-weight: 700;
    color: #0f172a;
    border-left: 4.5px solid #2563eb;
    padding-left: 10px;
    margin-top: 32px;
    margin-bottom: 14px;
    page-break-after: avoid;
    break-after: avoid;
    letter-spacing: -0.01em;
}}

h3 {{
    font-size: 11pt;
    font-weight: 700;
    color: #1e3a8a;
    margin-top: 22px;
    margin-bottom: 8px;
    page-break-after: avoid;
    break-after: avoid;
}}

h4 {{
    font-size: 9.8pt;
    font-weight: 700;
    color: #334155;
    margin-top: 16px;
    margin-bottom: 6px;
    page-break-after: avoid;
    break-after: avoid;
}}

p {{
    margin: 0 0 12px 0;
    text-align: justify;
}}

ul, ol {{
    margin: 0 0 14px 0;
    padding-left: 22px;
}}

li {{
    margin-bottom: 5px;
}}

hr {{
    border: none;
    border-top: 1px solid #e2e8f0;
    margin: 24px 0;
}}

strong {{
    color: #0f172a;
}}

/* ==================== TABLES ==================== */
table {{
    width: 100%;
    border-collapse: collapse;
    margin: 16px 0 20px 0;
    font-size: 8.5pt;
    page-break-inside: avoid;
    break-inside: avoid;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    overflow: hidden;
}}

thead tr {{
    background-color: #1e293b;
    color: #ffffff;
}}

th {{
    padding: 7px 10px;
    text-align: left;
    font-weight: 600;
    letter-spacing: 0.02em;
    border: 1px solid #334155;
}}

td {{
    padding: 6px 10px;
    border: 1px solid #e2e8f0;
    color: #334155;
    vertical-align: middle;
}}

tbody tr:nth-child(even) {{
    background-color: #f8fafc;
}}

tbody tr:hover {{
    background-color: #f1f5f9;
}}

/* ==================== CODE BLOCKS & PREGEL ==================== */
pre {{
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-left: 3.5px solid #3b82f6;
    border-radius: 6px;
    padding: 10px 14px;
    margin: 14px 0 18px 0;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
    font-size: 7.8pt;
    line-height: 1.45;
    color: #1e293b;
    overflow-x: auto;
    page-break-inside: auto;
    break-inside: auto;
}}

code {{
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
    font-size: 8.5pt;
    background: #f1f5f9;
    color: #0f172a;
    padding: 1.5px 5px;
    border-radius: 3px;
    border: 1px solid #e2e8f0;
}}

pre code {{
    background: transparent;
    padding: 0;
    border: none;
    font-size: inherit;
}}

/* Pygments Syntax Colors */
{pygments_css}

/* ==================== SCREENSHOT CARDS ==================== */
.screenshot-card {{
    border: 1.5px dashed #3b82f6;
    border-radius: 8px;
    background: #f0f7ff;
    margin: 18px 0 24px 0;
    overflow: hidden;
    page-break-inside: avoid;
    break-inside: avoid;
}}

.sc-header {{
    background: #e0eeff;
    padding: 8px 14px;
    border-bottom: 1px solid #bfdbfe;
    display: flex;
    align-items: center;
    gap: 12px;
}}

.sc-badge {{
    background: #2563eb;
    color: #ffffff;
    font-size: 7pt;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    padding: 2px 7px;
    border-radius: 3px;
}}

.sc-title {{
    font-size: 9pt;
    font-weight: 700;
    color: #1e3a8a;
}}

.sc-body {{
    padding: 28px 20px;
    min-height: 200px;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
}}

.sc-placeholder {{
    max-width: 540px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
}}

.sc-icon {{
    margin-bottom: 4px;
}}

.sc-prompt {{
    font-size: 10pt;
    font-weight: 800;
    color: #1d4ed8;
    letter-spacing: 0.05em;
}}

.sc-detail {{
    font-size: 8.2pt;
    color: #475569;
    line-height: 1.45;
}}

/* ==================== FIGURE CONTAINER ==================== */
.figure-container {{
    margin: 20px 0 26px 0;
    text-align: center;
    page-break-inside: avoid;
    break-inside: avoid;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    padding: 12px;
    background: #ffffff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}}

.network-figure {{
    max-width: 100%;
    height: auto;
    border-radius: 4px;
    display: block;
    margin: 0 auto;
}}

.figure-caption {{
    font-size: 8.5pt;
    color: #475569;
    margin-top: 10px;
    text-align: center;
    line-height: 1.45;
    padding: 0 16px;
}}

/* ==================== MATH FORMULAS ==================== */
.katex-display {{
    margin: 12px 0 !important;
    font-size: 10.5pt !important;
}}

/* ==================== LINKS ==================== */
a {{
    color: #2563eb;
    text-decoration: none;
    font-weight: 500;
}}

a:hover {{
    text-decoration: underline;
}}

/* Print specific optimizations */
@media print {{
    body {{
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }}
}}
</style>
</head>
<body>

<header class="doc-header">
  <div class="doc-course-tag">INT315 – Cluster Computing &bull; Capstone Project Report</div>
  <div class="doc-main-title">Project 15: Bus Route Optimization using Apache Spark GraphX</div>
  <div class="doc-subtitle">Large-Scale Urban Transit Network Analysis, Congestion Modeling &amp; Topological Express Optimization</div>
  
  <div class="doc-meta-grid">
    <div class="meta-item">
      <div class="meta-label">Author / Student</div>
      <div class="meta-val">Aman Singh</div>
    </div>
    <div class="meta-item">
      <div class="meta-label">Course Code</div>
      <div class="meta-val">INT315 &bull; Cluster Computing</div>
    </div>
    <div class="meta-item">
      <div class="meta-label">Target Network</div>
      <div class="meta-val">Delhi Bus Network (DTC / DIMTS)</div>
    </div>
    <div class="meta-item">
      <div class="meta-label">Framework &amp; Engine</div>
      <div class="meta-val">Apache Spark GraphX (Scala 2.12)</div>
    </div>
  </div>
</header>

<main>
{html_body}
</main>

</body>
</html>
"""

    with open(REPORT_HTML_PATH, "w", encoding="utf-8") as f:
        f.write(full_html)
    print(f"Generated HTML report at: {REPORT_HTML_PATH} ({len(full_html)} bytes)")

def convert_html_to_pdf():
    chrome_path = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    if not os.path.exists(chrome_path):
        print(f"Error: Google Chrome not found at {chrome_path}")
        sys.exit(1)

    cmd = [
        chrome_path,
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        "--virtual-time-budget=6000",
        "--run-all-compositor-stages-before-draw",
        "--no-pdf-header-footer",
        f"--print-to-pdf={OUTPUT_PDF_PATH}",
        REPORT_HTML_PATH
    ]
    print("Running Google Chrome Headless to generate PDF...")
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if os.path.exists(OUTPUT_PDF_PATH):
        size_kb = os.path.getsize(OUTPUT_PDF_PATH) / 1024
        print(f"Successfully generated PDF: {OUTPUT_PDF_PATH} ({size_kb:.1f} KB)")
    else:
        print("Failed to generate PDF. Chrome error output:")
        print(result.stderr)
        sys.exit(1)

if __name__ == "__main__":
    build_html_report()
    convert_html_to_pdf()
