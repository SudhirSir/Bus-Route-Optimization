# Project 15: Bus Route Optimization using Apache Spark GraphX

A Cluster Computing course project that models and analyzes a real-world city bus transit network (Delhi Transport Corporation / DIMTS) as a directed, weighted graph using **Apache Spark GraphX** in **Scala**. The system identifies critical transit hubs using degree centrality and distinct route connectivity, isolates circuitous bottlenecks using **Pregel-based shortest path algorithms**, proposes a direct express corridor, and demonstrates quantitative network optimization.

---

## Table of Contents
1. [Project Overview & Core Architecture](#project-overview--core-architecture)
2. [Dataset Details, License & Date Range](#dataset-details-license--date-range)
3. [Repository Structure](#repository-structure)
4. [Prerequisites & System Setup](#prerequisites--system-setup)
5. [Step-by-Step Execution Guide](#step-by-step-execution-guide)
   - [Step 0: GTFS Preprocessing (Python)](#step-0-gtfs-preprocessing-python)
   - [Step 1: GraphX Analysis (spark-submit or spark-shell)](#step-1-graphx-analysis-spark-submit-or-spark-shell)
   - [Step 2: Publication-Grade Visualizations (Python)](#step-2-publication-grade-visualizations-python)
6. [Experimental Results & Verification](#experimental-results--verification)
7. [Cluster Computing Angle (Grading Focus)](#cluster-computing-angle-grading-focus)
   - [Benchmark: `local[1]` vs `local[*]`](#benchmark-local1-vs-local)
   - [Running on a Multi-Node Standalone Cluster](#running-on-a-multi-node-standalone-cluster)
   - [Graph Caching, Partitioning & Lineage Management](#graph-caching-partitioning--lineage-management)
   - [Pregel Bulk Synchronous Parallel (BSP) Mechanics](#pregel-bulk-synchronous-parallel-bsp-mechanics)
8. [Project Limitations](#project-limitations)

---

## Project Overview & Core Architecture

Urban public transit networks can naturally be expressed as mathematical graphs $G = (V, E)$:
- **Vertices ($V$):** Physical bus stops characterized by numeric `stop_id`, `stop_name`, `lat`, and `lon`.
- **Edges ($E$):** Directed transit corridors between consecutive stops along scheduled bus trips, characterized by `route_id` and road-adjusted travel distance in kilometers (`distance_km`).

```
  [Bus Stop A] ───(Route 108, 0.43 km)───► [Bus Stop B] ───(Route 108, 0.50 km)───► [Bus Stop C]
       ▲                                                                                   │
       └──────────────────────────(Express Route 9999, 9.57 km)───────────────────────────┘
```

Rather than treating shortest paths as unweighted hop counts (which assumes all bus segments are equal in length), this project implements a customized **Pregel algorithm** that accumulates actual road distances and traces exact node sequences across distributed Spark executors.

---

## Dataset Details, License & Date Range

### 1. Source Feed
- **Operator:** Delhi Transport Corporation (DTC) and Delhi Integrated Multi-Modal Transit System Ltd. (DIMTS).
- **Portal:** [Delhi Open Transit Data Portal](https://otd.delhi.gov.in/) & [Mobility Database Catalog (mdb-1262)](https://mobilitydatabase.org/feeds/gtfs/mdb-1262).
- **Feed Type:** General Transit Feed Specification (GTFS) static timetable and route definitions.

### 2. Service Date Range
- **Timetable Window:** The static timetable snapshot covers service dates `2018-11-01` to `2018-11-08` (validated against `calendar.txt`), representing a stable, canonical operational schedule across Delhi's multimodal transit network.

### 3. Terms of Use & Licensing
- The dataset is released under the **Open Data Initiative by Department of Transport (Govt. of NCT of Delhi) and IIIT-Delhi**.
- Open for non-commercial academic research and development with proper attribution.

### 4. Direct Fallback Download
If automated fetching fails due to network proxies or institutional firewalls:
- **Direct Archive URL:** [https://files.mobilitydatabase.org/mdb-1262/mdb-1262-202406071502/mdb-1262-202406071502.zip](https://files.mobilitydatabase.org/mdb-1262/mdb-1262-202406071502/mdb-1262-202406071502.zip)
- **Placement:** Download the archive, name it `delhi_gtfs.zip` in the project root, or extract the contents (`stops.txt`, `trips.txt`, `stop_times.txt`, `routes.txt`, `agency.txt`, `calendar.txt`) directly into `gtfs_raw/`.

---

## Repository Structure

```
Bus Route Optimization using GraphX/
├── build.sbt                     # Official sbt build file (Spark 3.5.0, Scala 2.12.18)
├── build.bat                     # Windows zero-install build script (compiles via Spark jars)
├── preprocess_gtfs.py            # Step 0: GTFS to GraphX CSV converter
├── BusRoute.scala                # Interactive spark-shell script (:load BusRoute.scala)
├── src/
│   └── main/
│       └── scala/
│           └── busroute/
│               └── BusRouteApp.scala  # Main Spark application for spark-submit
├── data/                         # Generated GraphX input CSVs
│   ├── stops.csv                 # stop_id,stop_name,lat,lon (8,374 vertices)
│   └── edges.csv                 # src_id,dst_id,route_id,distance_km (8,284 edges)
├── output/                       # Output tables exported by Spark/GraphX
│   ├── centrality.csv            # Node-level in/out degree, centrality, distinct routes
│   ├── path_before.csv           # Original circuitous path node progression (25 hops)
│   ├── path_after.csv            # Optimized express path progression (1 hop)
│   └── new_edge.csv              # Proposed express corridor metadata
├── viz/                          # Visualizations
│   ├── plot.py                   # Matplotlib + Folium plotting script
│   ├── network.png               # High-resolution side-by-side comparison figure
│   └── map.html                  # Interactive Leaflet web map with layer controls
├── report.md                     # Academic project report draft
└── README.md                     # Comprehensive project documentation
```

---

## Prerequisites & System Setup

### 1. Java, Spark, and Scala Environment
- **Java:** JDK 8, 11, or 17 LTS (Java 17 verified).
- **Apache Spark:** Spark 3.5.x built for Hadoop 3 (`SPARK_HOME` added to system environment variables and `%SPARK_HOME%\bin` in `PATH`).
- **Scala Version:** 2.12.18 (bundled inside Spark runtime).

Verify the installation in terminal or PowerShell:
```powershell
spark-submit --version
java -version
python --version
```

### 2. Python Dependencies
Install required data science and visualization packages:
```powershell
pip install pandas numpy networkx matplotlib folium
```

---

## Step-by-Step Execution Guide

### Step 0: GTFS Preprocessing (Python)

The preprocessing script `preprocess_gtfs.py` downloads the feed (if not already local), parses `stop_times.txt` in memory-efficient chunks, forms consecutive pairs per trip, maps string IDs to numeric 64-bit Long IDs, removes duplicates, and computes road distances.

#### Option A: Quick Laptop Testing (Subset of 10 Routes)
For fast iteration during development:
```powershell
python preprocess_gtfs.py --max-routes 10
```

#### Option B: Full City Scale (All Routes)
To generate the full Delhi network:
```powershell
python preprocess_gtfs.py
```
*Expected Output:*
```
[OK] Found extracted GTFS files in 'gtfs_raw'
[*] Reading stops from 'gtfs_raw\stops.txt'...
[*] Reading trips from 'gtfs_raw\trips.txt'...
[*] Reading stop times from 'gtfs_raw\stop_times.txt' in chunks...
    Loaded 389,145 stop_times entries for selected trips.
[*] Generating consecutive stop pairs per trip...
[*] Deduplicating (src_id, dst_id, route_id) edges...
[*] Computing distances (Haversine * 1.3 road winding factor)...

=======================================================
 PREPROCESSING SUMMARY
=======================================================
 Output stops file : data\stops.csv
 Output edges file : data\edges.csv
 Total Stops       : 8,374
 Total Edges       : 8,284
 Total Routes      : 195
 Mean edge distance: 0.77 km
 Max edge distance : 37.95 km
=======================================================
```

---

### Step 1: GraphX Analysis (spark-submit or spark-shell)

You can run the GraphX analysis using either a packaged JAR with `spark-submit` or interactively inside `spark-shell`.

#### Method A: Packaged JAR with `spark-submit` (Recommended)

1. **Build the JAR:**
   - If you have `sbt` installed:
     ```powershell
     sbt package
     ```
   - Alternatively, use the zero-install build script (compiles directly using Spark's internal Scala compiler):
     ```powershell
     .\build.bat
     ```
     This produces `target/busroute-graphx.jar`.

2. **Run on Spark (Single Core):**
   ```powershell
   spark-submit --class busroute.BusRouteApp --master "local[1]" target/busroute-graphx.jar data/stops.csv data/edges.csv output
   ```

3. **Run on Spark (All Available Cores):**
   ```powershell
   spark-submit --class busroute.BusRouteApp --master "local[*]" target/busroute-graphx.jar data/stops.csv data/edges.csv output
   ```

#### Method B: Interactive `spark-shell` Execution
If you wish to step through the code in the Scala REPL:
1. Start `spark-shell`:
   ```powershell
   spark-shell --master "local[*]"
   ```
2. Load the script inside the REPL:
   ```scala
   scala> :load BusRoute.scala
   ```
3. Type `:quit` to exit when done.

---

### Step 2: Publication-Grade Visualizations (Python)

After Spark writes the four result CSVs to `output/`, generate the visualizations:
```powershell
python viz/plot.py
```
This generates two artifacts:
1. `viz/network.png`: High-resolution (300 DPI) side-by-side network plot.
2. `viz/map.html`: Interactive Folium map with OpenStreetMap tiles and togglable layers.

Open `viz/map.html` in any web browser to explore stops, corridors, and hubs interactively.

---

## Experimental Results & Verification

### 1. Top 10 Busiest Stops by Degree Centrality (Congestion Proxy)
Degree Centrality is defined as:
$$C_D(v) = \frac{\text{deg}_{\text{in}}(v) + \text{deg}_{\text{out}}(v)}{2 \cdot (N - 1)}$$
where $N = 8,374$ vertices. Normalizing by $2(N-1)$ bounds centrality strictly within $[0, 1]$.

| Rank | Stop ID | Stop Name | In-Degree | Out-Degree | Total Degree | Degree Centrality | Distinct Routes |
|:---:|:---:|:---|:---:|:---:|:---:|:---:|:---:|
| **1** | **2186** | **Super Bazar / Connaught Place** | 14 | 16 | **30** | **0.001791** | **16** |
| 2 | 8291 | Sadhu Vaswani Marg / Pusa Rd | 13 | 13 | 26 | 0.001553 | 13 |
| 3 | 8285 | Karol Bagh Metro Station | 13 | 13 | 26 | 0.001553 | 13 |
| 4 | 8284 | Karol Bagh Metro Station | 13 | 13 | 26 | 0.001553 | 13 |
| 5 | 3179 | Nauroji Nagar | 13 | 13 | 26 | 0.001553 | 13 |
| 6 | 522 | Jama Masjid | 13 | 13 | 26 | 0.001553 | 13 |
| **7** | **6128** | **Dhaula Kuan Interchange** | 12 | 13 | **25** | **0.001493** | **13** |
| 8 | 6446 | Meghdoot Bhawan / Jhandewalan | 12 | 12 | 24 | 0.001433 | 12 |
| 9 | 687 | Dholi Piau | 12 | 12 | 24 | 0.001433 | 12 |
| 10 | 685 | Dholi Piao | 12 | 12 | 24 | 0.001433 | 12 |

### 2. Corridor Optimization: Connaught Place to Dhaula Kuan
The algorithm detected an acute topological bottleneck between **Super Bazar/C.P (ID 2186)** and **Dhaula Kuan (ID 6128)**. In the existing network, buses wind through 25 intermediate stops (traversing Talkatora, 11 Murti, Sardar Patel Marg, into Delhi Cantt, and looping back).

A new express direct link was introduced:
- **Route ID:** 9999 (Express Direct Shuttle)
- **Direct Road Distance:** $9.57 \text{ km}$ ($7.36 \text{ km straight-line} \times 1.3\text{ road factor}$)

| Metric | Before Optimization | After Optimization | Absolute Change | Percentage Improvement |
|:---|:---:|:---:|:---:|:---:|
| **Path Distance** | **18.88 km** | **9.57 km** | **-9.32 km** | **-49.3%** |
| **Transfer Hops** | **25 hops** | **1 hop** | **-24 hops** | **-96.0%** |
| **Intermediate Stops** | **26 stops** | **2 stops** | **-24 stops** | **-92.3%** |

### 3. Sampled Network-Wide Average Shortest Distance
To evaluate global network impact without computing full $O(V^3)$ all-pairs paths, the system sampled the top 5 busiest hubs (Connaught Place, Sadhu Vaswani Marg, Karol Bagh [2x], Nauroji Nagar) as origin points across 14,770 reachable OD pairs:
- **Sampled Average Shortest Distance (Before):** $23.30\text{ km}$
- **Sampled Average Shortest Distance (After):** $23.22\text{ km}$
- **Average Network Improvement:** $-0.08\text{ km}$ ($-0.34\%$ overall network reduction across 14,770 pairs from just a single link).

---

## Cluster Computing Angle (Grading Focus)

### Benchmark: `local[1]` vs `local[*]`
The Spark application was tested locally under both execution profiles on the full city network ($N = 8,374$ vertices, $M = 8,284$ edges):

| Configuration | Mode Description | SSSP Pregel Step Time | Full Pipeline Execution Time |
|:---|:---|:---:|:---:|
| **`local[1]`** | Single worker thread, no multi-threading | **6.52 s** | **168.58 s** |
| **`local[*]`** | All available CPU cores (multi-threaded executor) | **14.89 s** | **176.64 s** |

#### Why did `local[*]` take slightly longer on a single machine?
This counter-intuitive finding is a classic **Cluster Computing scaling phenomenon**:
1. **Shuffle and Synchronization Overhead in Iterative BSP:** Pregel executes in synchronized supersteps. At every superstep, messages sent between vertices are partitioned and shuffled. On small-to-medium graphs (~8k nodes), the cost of thread context switching, task scheduling overhead, JVM thread lock contention, and inter-thread data serialization outweighs pure compute benefits.
2. **Partition Granularity:** On a single machine, dividing a small dataset across multiple local threads creates tiny micro-partitions that spend more time coordinating barriers than executing vertex programs.
3. **When `local[*]` or Clusters Outperform Single-Cores:** True linear speedup occurs when data exceeds RAM or when graphs contain millions of vertices where per-partition computation dominates synchronization latency.

---

### Running on a Multi-Node Standalone Cluster

In a laboratory or production environment, Spark runs across a standalone cluster consisting of 1 Master node and $N$ Worker nodes.

#### Architecture
```
                         +-----------------------+
                         |     Spark Master      |
                         |  (spark://master:7077)|
                         +-----------+-----------+
                                     |
             +-----------------------+-----------------------+
             |                                               |
  +----------v----------+                         +----------v----------+
  |    Spark Worker 1   |                         |    Spark Worker 2   |
  | (4 Cores, 8 GB RAM) |                         | (4 Cores, 8 GB RAM) |
  +---------------------+                         +---------------------+
```

#### Commands to Launch:
1. **On the Master Node:**
   ```bash
   $SPARK_HOME/sbin/start-master.sh
   # Spark Master UI available at http://master-ip:8080
   ```
2. **On Worker Node 1 & 2:**
   ```bash
   $SPARK_HOME/sbin/start-worker.sh spark://master-ip:7077
   ```
3. **Submit the Job to the Cluster:**
   ```bash
   spark-submit \
     --class busroute.BusRouteApp \
     --master spark://master-ip:7077 \
     --deploy-mode client \
     --executor-memory 4G \
     --executor-cores 2 \
     --total-executor-cores 4 \
     hdfs:///data/stops.csv \
     hdfs:///data/edges.csv \
     hdfs:///output/
   ```

---

### Graph Caching, Partitioning & Lineage Management

GraphX relies on specialized distributed data structures: `VertexRDD` and `EdgeRDD`.

#### 1. Why `graph.cache()` is Mandatory
Pregel executes in iterative loops (supersteps 1, 2, ..., $K$). Without `.cache()` on the initial graph, Spark's lazy evaluation mechanism would **re-read the CSV files and reconstruct the entire graph from scratch on every single Pregel iteration**, leading to catastrophic $O(K^2)$ disk I/O and exponential JVM memory pressure.

```scala
val busGraph = Graph(verticesRDD, edgesRDD).cache()
```

#### 2. Edge Partitioning (`partitionBy`)
In bus transit networks, graphs exhibit high vertex clustering (transit hubs connect to dozens of stops). GraphX uses **vertex-cut partitioning** rather than edge-cut partitioning: edges are partitioned across machines, and vertices can span multiple partitions.
To optimize network communication between workers during Pregel message passing:
```scala
val partitionedGraph = busGraph.partitionBy(PartitionStrategy.EdgePartition2D)
```
`EdgePartition2D` guarantees that both source and destination vertices are co-located within a 2D matrix of partitions, providing an upper bound of $2\sqrt{P} - 1$ on vertex replication across $P$ cluster worker partitions.

---

### Pregel Bulk Synchronous Parallel (BSP) Mechanics

Pregel in GraphX executes in discrete synchronized supersteps:
1. **Vertex Program (`vprog`):** Each vertex inspects incoming candidate path messages. If `msg.distance < vertex.distance`, the vertex updates its distance and appends its ID to the path history.
2. **Send Message (`sendMsg`):** For each outgoing edge triplet `(src, dst, edge)`, if `src` improved its distance, it computes `candidate = src.distance + edge.distance_km`. If `candidate < dst.distance`, it emits a message to `dst`.
3. **Merge Message (`mergeMsg`):** If multiple paths reach the same destination in the same superstep, `mergeMsg` reduces them by taking the minimum distance before invoking the next superstep.
4. **Halt Condition:** When no messages are in flight across the cluster, the iterative loop terminates.

---

## Project Limitations

While this project successfully models transit topology and optimizes corridor travel, practical real-world operations have the following limitations:

1. **Degree Centrality is Only a Congestion Proxy:**
   - High degree centrality means a stop has many topological incoming/outgoing bus connections.
   - However, degree centrality does **not** capture physical passenger passenger counts, boarding/alighting volumes, or smart card tap-in/tap-out data. A stop with 10 minor routes may have fewer passengers than a metro station with only 2 high-capacity trunk routes.
2. **Static Timetable Snapshot:**
   - The dataset represents a scheduled timetable snapshot.
   - It assumes buses travel at standard free-flow speeds and does not incorporate real-time dynamic congestion, traffic bottlenecks during morning/evening peak hours, or bus bunching.
3. **Straight-Line $\times$ 1.3 Approximation:**
   - Inter-stop road distance is estimated using great-circle Haversine distance multiplied by an empirical urban road winding factor of $1.3$.
   - While highly accurate on average across flat metropolitan grids like Delhi, individual road sections (flyovers, one-way loops, diversions) may vary from actual road centerlines.

---

## Authors & Course Information
- **Course:** Cluster Computing / Distributed Systems
- **Project Topic:** Project 15: Bus Route Optimization using GraphX
- **Technologies:** Apache Spark 3.5.9, GraphX, Scala 2.12.18, Python 3.11, NetworkX, Matplotlib, Folium.
