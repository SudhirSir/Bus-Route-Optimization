/**
 * BusRoute.scala
 * ==============
 * Project 15: Bus Route Optimization using GraphX (Interactive spark-shell script)
 *
 * HOW TO RUN:
 *   1. Launch spark-shell from the project root directory:
 *        spark-shell --master "local[*]"
 *   2. In the interactive Scala REPL prompt, type:
 *        scala> :load BusRoute.scala
 *
 * This script will run the full pipeline interactively, printing all progress,
 * congestion rankings, Pregel shortest path results, and saving outputs to output/.
 */

import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD
import java.io.{File, PrintWriter}
import scala.math._

println("=" * 80)
println(">>> Loading Project 15: Bus Route Optimization using GraphX...")
println("=" * 80)

val stopsPath = "data/stops.csv"
val edgesPath = "data/edges.csv"
val outputDir = "output"

// 1. Load DataFrames
println("[1/7] Reading stops.csv and edges.csv...")
val stopsDF = spark.read.option("header", "true").option("inferSchema", "true").csv(stopsPath)
val edgesDF = spark.read.option("header", "true").option("inferSchema", "true").csv(edgesPath)

// 2. Build GraphX Graph
println("[2/7] Constructing GraphX directed graph...")
val verticesRDD: RDD[(VertexId, (String, Double, Double))] = stopsDF.rdd.map { row =>
  val id = row.getAs[Number]("stop_id").longValue()
  val name = Option(row.getAs[String]("stop_name")).getOrElse(s"Stop_$id").trim
  val lat = row.getAs[Number]("lat").doubleValue()
  val lon = row.getAs[Number]("lon").doubleValue()
  (id, (name, lat, lon))
}

val edgesRDD: RDD[Edge[(Long, Double)]] = edgesDF.rdd.map { row =>
  val src = row.getAs[Number]("src_id").longValue()
  val dst = row.getAs[Number]("dst_id").longValue()
  val routeId = row.getAs[Number]("route_id").longValue()
  val dist = row.getAs[Number]("distance_km").doubleValue()
  Edge(src, dst, (routeId, dist))
}

val busGraph = Graph(verticesRDD, edgesRDD).cache()
val numVertices = busGraph.numVertices
val numEdges = busGraph.numEdges
println(s"      Graph constructed: $numVertices vertices, $numEdges edges.")

val namesMap = busGraph.vertices.mapValues(_._1).collect().toMap
val coordsMap = busGraph.vertices.mapValues(v => (v._2, v._3)).collect().toMap

// 3. Centrality and Distinct Routes
println("[3/7] Computing in/out degrees, degree centrality, and distinct routes...")
val inDeg = busGraph.inDegrees
val outDeg = busGraph.outDegrees
val totDeg = busGraph.degrees

val stopRoutePairs = busGraph.edges.flatMap { edge =>
  Seq((edge.srcId, edge.attr._1), (edge.dstId, edge.attr._1))
}.distinct()

val routesPerStop = stopRoutePairs.map { case (sid, _) => (sid, 1) }.reduceByKey(_ + _)
val normFactor = if (numVertices > 1) 2.0 * (numVertices - 1) else 1.0

val stopMetrics = busGraph.vertices
  .leftOuterJoin(totDeg).map { case (id, (attr, dOpt)) => (id, (attr, dOpt.getOrElse(0))) }
  .leftOuterJoin(inDeg).map { case (id, ((attr, tot), inOpt)) => (id, (attr, tot, inOpt.getOrElse(0))) }
  .leftOuterJoin(outDeg).map { case (id, (((attr, tot, inD), outOpt))) => (id, (attr, tot, inD, outOpt.getOrElse(0))) }
  .leftOuterJoin(routesPerStop).map { case (id, (((attr, tot, inD, outD)), rOpt)) =>
    val centrality = tot.toDouble / normFactor
    val distinctRoutes = rOpt.getOrElse(0)
    (id, attr._1, attr._2, attr._3, inD, outD, tot, centrality, distinctRoutes)
  }.cache()

println("\n--- TOP 10 BUSIEST STOPS BY DEGREE CENTRALITY ---")
stopMetrics.sortBy(_._8, ascending = false).take(10).zipWithIndex.foreach { case ((id, name, _, _, inD, outD, tot, cent, r), idx) =>
  println(f" ${idx+1}%2d. Stop $id%-6d | In: $inD%2d | Out: $outD%2d | Tot: $tot%2d | Centrality: $cent%.6f | Routes: $r%2d | $name")
}

println("\n--- TOP 10 STOPS BY DISTINCT ROUTES ---")
stopMetrics.sortBy(_._9, ascending = false).take(10).zipWithIndex.foreach { case ((id, name, _, _, _, _, tot, cent, r), idx) =>
  println(f" ${idx+1}%2d. Stop $id%-6d | Routes: $r%2d | TotDeg: $tot%2d | Centrality: $cent%.6f | $name")
}

// Export centrality.csv
new File(outputDir).mkdirs()
val centFile = new PrintWriter(new File(s"$outputDir/centrality.csv"), "UTF-8")
centFile.println("stop_id,stop_name,lat,lon,in_degree,out_degree,total_degree,degree_centrality,distinct_routes")
stopMetrics.collect().sortBy(-_._7).foreach { case (id, name, lat, lon, inD, outD, tot, cent, routes) =>
  centFile.println(s"""$id,"$name",$lat,$lon,$inD,$outD,$tot,$cent,$routes""")
}
centFile.close()
println(s"[OK] Exported $outputDir/centrality.csv")

// 4. Pregel SSSP Definition
def haversineRoadKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double = {
  val r = 6371.0
  val dLat = toRadians(lat2 - lat1)
  val dLon = toRadians(lon2 - lon1)
  val a = sin(dLat / 2.0) * sin(dLat / 2.0) + cos(toRadians(lat1)) * cos(toRadians(lat2)) * sin(dLon / 2.0) * sin(dLon / 2.0)
  val c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a))
  r * c * 1.3
}

def runPregelSSSP(g: Graph[(String, Double, Double), (Long, Double)], sourceId: VertexId): Graph[(Double, List[VertexId]), (Long, Double)] = {
  val initialGraph = g.mapVertices { case (id, _) =>
    if (id == sourceId) (0.0, List(sourceId))
    else (Double.PositiveInfinity, List.empty[VertexId])
  }

  initialGraph.pregel[(Double, List[VertexId])](
    initialMsg = (Double.PositiveInfinity, List.empty[VertexId]),
    maxIterations = 100,
    activeDirection = EdgeDirection.Out
  )(
    (id, cur, msg) => if (msg._1 < cur._1) msg else cur,
    triplet => {
      if (triplet.srcAttr._1 != Double.PositiveInfinity) {
        val newDist = triplet.srcAttr._1 + triplet.attr._2
        if (newDist < triplet.dstAttr._1) {
          Iterator((triplet.dstId, (newDist, triplet.srcAttr._2 :+ triplet.dstId)))
        } else Iterator.empty
      } else Iterator.empty
    },
    (a, b) => if (a._1 < b._1) a else b
  )
}

// 5. Shortest Path Before
val originId: VertexId = 2186L // Super Bazar/C.P
val destId: VertexId   = 6128L // Dhaula Kuan

println(s"\n[4/7] Running Pregel SSSP from origin hub: ${namesMap(originId)}...")
val t0 = System.currentTimeMillis()
val ssspBefore = runPregelSSSP(busGraph, originId).cache()
val destBefore = ssspBefore.vertices.filter(_._1 == destId).collect().head._2
val tPregel = System.currentTimeMillis() - t0
println(f"      Pregel execution completed in ${tPregel / 1000.0}%.3f seconds ($tPregel ms).")
println(f"      Current path to ${namesMap(destId)}: ${destBefore._1}%.2f km, ${destBefore._2.length - 1} hops.")

// Export path_before.csv
val pbFile = new PrintWriter(new File(s"$outputDir/path_before.csv"), "UTF-8")
pbFile.println("seq_order,stop_id,stop_name,lat,lon,cumulative_dist_km")
var cDist = 0.0
for (i <- destBefore._2.indices) {
  val nid = destBefore._2(i)
  val (lat, lon) = coordsMap(nid)
  if (i > 0) {
    val (pLat, pLon) = coordsMap(destBefore._2(i - 1))
    cDist += haversineRoadKm(pLat, pLon, lat, lon)
  }
  pbFile.println(f"""$i,$nid,"${namesMap(nid)}",$lat,$lon,$cDist%.4f""")
}
pbFile.close()
println(s"[OK] Exported $outputDir/path_before.csv")

// 6. Propose Direct Express Link & Re-evaluate
println("\n[5/7] Proposing new express direct link between C.P. and Dhaula Kuan...")
val (sLat, sLon) = coordsMap(originId)
val (dLat, dLon) = coordsMap(destId)
val directDist = haversineRoadKm(sLat, sLon, dLat, dLon)
val newRouteId = 9999L

val neFile = new PrintWriter(new File(s"$outputDir/new_edge.csv"), "UTF-8")
neFile.println("src_id,src_name,dst_id,dst_name,route_id,distance_km")
neFile.println(f"""$originId,"${namesMap(originId)}",$destId,"${namesMap(destId)}",$newRouteId,$directDist%.4f""")
neFile.println(f"""$destId,"${namesMap(destId)}",$originId,"${namesMap(originId)}",$newRouteId,$directDist%.4f""")
neFile.close()
println(s"[OK] Exported $outputDir/new_edge.csv")

val augmentedEdges = busGraph.edges.union(sc.parallelize(Seq(
  Edge(originId, destId, (newRouteId, directDist)),
  Edge(destId, originId, (newRouteId, directDist))
)))
val optimizedGraph = Graph(busGraph.vertices, augmentedEdges).cache()

println("\n[6/7] Re-running Pregel SSSP on optimized graph...")
val ssspAfter = runPregelSSSP(optimizedGraph, originId).cache()
val destAfter = ssspAfter.vertices.filter(_._1 == destId).collect().head._2

println(f"      Optimized path to ${namesMap(destId)}: ${destAfter._1}%.2f km, ${destAfter._2.length - 1} hops.")
println(f"      Savings: ${destBefore._1 - destAfter._1}%.2f km reduction, ${destBefore._2.length - destAfter._2.length} fewer hops!")

// Export path_after.csv
val paFile = new PrintWriter(new File(s"$outputDir/path_after.csv"), "UTF-8")
paFile.println("seq_order,stop_id,stop_name,lat,lon,cumulative_dist_km")
var cDistA = 0.0
for (i <- destAfter._2.indices) {
  val nid = destAfter._2(i)
  val (lat, lon) = coordsMap(nid)
  if (i > 0) {
    val (pLat, pLon) = coordsMap(destAfter._2(i - 1))
    cDistA += haversineRoadKm(pLat, pLon, lat, lon)
  }
  paFile.println(f"""$i,$nid,"${namesMap(nid)}",$lat,$lon,$cDistA%.4f""")
}
paFile.close()
println(s"[OK] Exported $outputDir/path_after.csv")

println("\n[7/7] Done! All tables exported to output/ folder.")
println("=" * 80)
