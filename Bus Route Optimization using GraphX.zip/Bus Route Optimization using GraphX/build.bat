@echo off
REM ============================================================================
REM build.bat - Compiles BusRouteApp.scala into target/busroute-graphx.jar
REM Uses the Scala compiler included inside Spark's jars directory.
REM ============================================================================

echo [*] Checking SPARK_HOME...
if "%SPARK_HOME%"=="" (
    set SPARK_HOME=C:\Spark\spark-3.5.9-bin-hadoop3
)
echo [OK] Using SPARK_HOME: %SPARK_HOME%

if not exist target mkdir target
if not exist bin mkdir bin

echo [*] Compiling src/main/scala/busroute/BusRouteApp.scala...
java -cp "%SPARK_HOME%\jars\*" scala.tools.nsc.Main -usejavacp -d bin src/main/scala/busroute/BusRouteApp.scala
if errorlevel 1 (
    echo [ERROR] Scala compilation failed.
    exit /b 1
)

echo [*] Packaging JAR into target/busroute-graphx.jar...
jar cvf target/busroute-graphx.jar -C bin .
if errorlevel 1 (
    echo [ERROR] JAR creation failed.
    exit /b 1
)

echo ============================================================================
echo [SUCCESS] Built target/busroute-graphx.jar successfully!
echo You can now run:
echo   spark-submit --class busroute.BusRouteApp --master "local[*]" target/busroute-graphx.jar
echo ============================================================================
