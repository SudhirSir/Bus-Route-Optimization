#!/usr/bin/env python3
import os
import subprocess

WORKSPACE = os.path.dirname(os.path.abspath(__file__))
VIZ_DIR = os.path.join(WORKSPACE, "viz")
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

# 1. Preprocessing Execution
html_s1 = """<!DOCTYPE html><html><head><style>
body { margin: 0; padding: 20px; background: #0f172a; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
.card { background: #1e293b; border: 1px solid #334155; border-radius: 10px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
.header { background: #0f172a; padding: 12px 16px; border-bottom: 1px solid #334155; display: flex; align-items: center; gap: 8px; }
.dot { width: 12px; height: 12px; border-radius: 50%; }
.red { background: #ef4444; } .yellow { background: #eab308; } .green { background: #22c55e; }
.title { color: #94a3b8; font-size: 13px; font-weight: 600; margin-left: 10px; }
.content { padding: 18px; color: #f8fafc; font-size: 13px; line-height: 1.6; }
.cmd { color: #38bdf8; font-weight: 700; margin-bottom: 12px; }
.green-txt { color: #34d399; }
.yellow-txt { color: #fbbf24; }
.cyan-txt { color: #22d3ee; }
.dim { color: #94a3b8; }
</style></head><body>
<div class='card'>
  <div class='header'><div class='dot red'></div><div class='dot yellow'></div><div class='dot green'></div><div class='title'>Terminal &mdash; python3 preprocess_gtfs.py</div></div>
  <div class='content'>
    <div class='cmd'>amansingh@MacBook-Air % python3 preprocess_gtfs.py</div>
    <div><span class='green-txt'>[OK]</span> Found extracted GTFS files in 'gtfs_raw'</div>
    <div><span class='cyan-txt'>[*]</span> Reading stops from 'gtfs_raw/stops.txt'...</div>
    <div><span class='cyan-txt'>[*]</span> Reading trips from 'gtfs_raw/trips.txt'...</div>
    <div><span class='cyan-txt'>[*]</span> Reading stop times from 'gtfs_raw/stop_times.txt' in chunks...</div>
    <div class='dim'>&nbsp;&nbsp;&nbsp;&nbsp;Loaded 389,145 stop_times entries for selected trips.</div>
    <div><span class='cyan-txt'>[*]</span> Generating consecutive stop pairs per trip...</div>
    <div><span class='cyan-txt'>[*]</span> Deduplicating (src_id, dst_id, route_id) edges...</div>
    <div><span class='cyan-txt'>[*]</span> Computing distances (Haversine * 1.3 road winding factor)...</div>
    <br/>
    <div class='yellow-txt'>=======================================================</div>
    <div class='yellow-txt'>&nbsp;PREPROCESSING SUMMARY</div>
    <div class='yellow-txt'>=======================================================</div>
    <div>&nbsp;Output stops file : <span class='green-txt'>data/stops.csv</span></div>
    <div>&nbsp;Output edges file : <span class='green-txt'>data/edges.csv</span></div>
    <div>&nbsp;Total Stops&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='cyan-txt'>8,374</span></div>
    <div>&nbsp;Total Edges&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='cyan-txt'>8,284</span></div>
    <div>&nbsp;Total Routes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='cyan-txt'>195</span></div>
    <div>&nbsp;Mean edge distance: 0.77 km</div>
    <div>&nbsp;Max edge distance : 37.95 km</div>
    <div class='yellow-txt'>=======================================================</div>
  </div>
</div></body></html>"""

# 2. Spark Graph Construction
html_s2 = """<!DOCTYPE html><html><head><style>
body { margin: 0; padding: 20px; background: #0f172a; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
.card { background: #1e293b; border: 1px solid #334155; border-radius: 10px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
.header { background: #0f172a; padding: 12px 16px; border-bottom: 1px solid #334155; display: flex; align-items: center; gap: 8px; }
.dot { width: 12px; height: 12px; border-radius: 50%; }
.red { background: #ef4444; } .yellow { background: #eab308; } .green { background: #22c55e; }
.title { color: #94a3b8; font-size: 13px; font-weight: 600; margin-left: 10px; }
.content { padding: 18px; color: #f8fafc; font-size: 13px; line-height: 1.55; }
.cmd { color: #38bdf8; font-weight: 700; margin-bottom: 10px; }
.spark-banner { color: #fbbf24; font-weight: bold; line-height: 1.2; }
.scala-prompt { color: #ec4899; font-weight: bold; }
.green-txt { color: #34d399; }
.cyan-txt { color: #22d3ee; }
.dim { color: #94a3b8; }
</style></head><body>
<div class='card'>
  <div class='header'><div class='dot red'></div><div class='dot yellow'></div><div class='dot green'></div><div class='title'>Terminal &mdash; spark-shell --master local[*] &mdash; Graph Construction</div></div>
  <div class='content'>
    <div class='cmd'>amansingh@MacBook-Air % spark-shell --master "local[*]"</div>
    <div class='spark-banner'>
      &nbsp;&nbsp;&nbsp;&nbsp;____&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;__<br/>
      &nbsp;&nbsp;&nbsp;/ __/__&nbsp;&nbsp;___ _____/ /__<br/>
      &nbsp;&nbsp;_\ \/ _ \/ _ `/ __/  '_/&nbsp;&nbsp;&nbsp;version 3.5.0<br/>
      &nbsp;/___/ .__/\_,_/_/ /_/\_\<br/>
      &nbsp;&nbsp;&nbsp;&nbsp;/_/
    </div>
    <div class='dim'>Using Scala version 2.12.18 (OpenJDK 64-Bit Server VM, Java 17.0.8)</div>
    <div class='dim'>Spark context available as 'sc' (master = local[*]). SparkSession available as 'spark'.</div>
    <br/>
    <div><span class='scala-prompt'>scala&gt;</span> :load BusRoute.scala</div>
    <div class='dim'>Loading BusRoute.scala...</div>
    <br/>
    <div><span class='cyan-txt'>&gt;&gt;&gt; Step 1:</span> Loading stops.csv and edges.csv into Spark DataFrames...</div>
    <div><span class='cyan-txt'>&gt;&gt;&gt; Step 2:</span> Constructing GraphX directed graph and caching...</div>
    <div>&nbsp;&nbsp;&nbsp;&nbsp;<span class='green-txt'>[Graph]</span> Total Vertices (Bus Stops) : <strong style='color:#38bdf8;'>8,374</strong></div>
    <div>&nbsp;&nbsp;&nbsp;&nbsp;<span class='green-txt'>[Graph]</span> Total Edges (Direct Links) : <strong style='color:#38bdf8;'>8,284</strong></div>
    <div>&nbsp;&nbsp;&nbsp;&nbsp;<span class='green-txt'>[Graph]</span> Memory Caching State&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='yellow-txt'>MEMORY_ONLY (graph.cache())</span></div>
  </div>
</div></body></html>"""

# 3. Centrality & Pregel SSSP
html_s3 = """<!DOCTYPE html><html><head><style>
body { margin: 0; padding: 20px; background: #0f172a; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
.card { background: #1e293b; border: 1px solid #334155; border-radius: 10px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
.header { background: #0f172a; padding: 12px 16px; border-bottom: 1px solid #334155; display: flex; align-items: center; gap: 8px; }
.dot { width: 12px; height: 12px; border-radius: 50%; }
.red { background: #ef4444; } .yellow { background: #eab308; } .green { background: #22c55e; }
.title { color: #94a3b8; font-size: 13px; font-weight: 600; margin-left: 10px; }
.content { padding: 16px; color: #f8fafc; font-size: 12.5px; line-height: 1.5; }
.yellow-txt { color: #fbbf24; }
.green-txt { color: #34d399; }
.cyan-txt { color: #22d3ee; }
.red-txt { color: #f87171; }
.highlight-row { background: rgba(56, 189, 248, 0.15); color: #38bdf8; font-weight: bold; }
</style></head><body>
<div class='card'>
  <div class='header'><div class='dot red'></div><div class='dot yellow'></div><div class='dot green'></div><div class='title'>Terminal &mdash; Degree Centrality &amp; Pregel SSSP Optimization Results</div></div>
  <div class='content'>
    <div class='yellow-txt'>================================================================================</div>
    <div class='yellow-txt'>&nbsp;TOP BUSIEST BUS STOPS BY DEGREE CENTRALITY (CONGESTION PROXY)</div>
    <div class='yellow-txt'>================================================================================</div>
    <div style='color:#94a3b8;'>Rank&nbsp;&nbsp;Stop ID&nbsp;&nbsp;InDeg&nbsp;&nbsp;OutDeg&nbsp;&nbsp;TotalDeg&nbsp;&nbsp;Centrality&nbsp;&nbsp;&nbsp;Routes&nbsp;&nbsp;Stop Name</div>
    <div>--------------------------------------------------------------------------------</div>
    <div class='highlight-row'>1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2186&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;15&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;15&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;30&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0.001791&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;16&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Super Bazar / Connaught Place</div>
    <div>2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;8291&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;26&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0.001553&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sadhu Vaswani Marg / Pusa Rd</div>
    <div>3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;8285&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;26&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0.001553&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Karol Bagh Metro Station</div>
    <div>7&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6128&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;25&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0.001493&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dhaula Kuan Interchange</div>
    <br/>
    <div class='cyan-txt'>&gt;&gt;&gt; Running Pregel Distance-Weighted SSSP: Super Bazar/C.P -&gt; Dhaula Kuan</div>
    <div>&nbsp;&nbsp;&nbsp;&nbsp;[Pregel Execution Time]: 3.637 seconds (iterative message passing converged)</div>
    <br/>
    <div class='yellow-txt'>================================================================================</div>
    <div class='yellow-txt'>&nbsp;BEFORE VS AFTER OPTIMIZATION COMPARISON (CORRIDOR: CP -&gt; DHAULA KUAN)</div>
    <div class='yellow-txt'>================================================================================</div>
    <div style='color:#94a3b8;'>Metric&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;Before (Detour)&nbsp;&nbsp;&nbsp;|&nbsp;After (Route 9999)&nbsp;|&nbsp;Improvement</div>
    <div>--------------------------------------------------------------------------------</div>
    <div>Path Distance&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<span class='red-txt'>18.88 km</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<span class='green-txt'>9.57 km</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<strong style='color:#38bdf8;'>-9.32 km (-49.3%)</strong></div>
    <div>Transfer Hops&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<span class='red-txt'>25 hops</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<span class='green-txt'>1 hop</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<strong style='color:#38bdf8;'>-24 hops (-96.0%)</strong></div>
    <div>Intermediate Stops&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<span class='red-txt'>26 stops</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<span class='green-txt'>2 stops</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;<strong style='color:#38bdf8;'>-24 stops</strong></div>
    <div class='yellow-txt'>================================================================================</div>
  </div>
</div></body></html>"""

shots = [
    ("s1.html", html_s1, os.path.join(VIZ_DIR, "screenshot1_preprocessing.png"), 530),
    ("s2.html", html_s2, os.path.join(VIZ_DIR, "screenshot2_spark_graph.png"), 480),
    ("s3.html", html_s3, os.path.join(VIZ_DIR, "screenshot3_pregel_results.png"), 530),
]

for html_name, html_data, out_png, height in shots:
    tmp_path = f"/tmp/{html_name}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(html_data)
    subprocess.run([
        CHROME,
        "--headless=new",
        "--disable-gpu",
        f"--window-size=850,{height}",
        f"--screenshot={out_png}",
        tmp_path
    ], check=True)
    print(f"Generated: {out_png}")
