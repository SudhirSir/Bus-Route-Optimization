#!/usr/bin/env python3
"""
generate_ppt.py
===============
Generates a clean, simple, student-friendly 8-slide presentation (16:9 widescreen)
for "Project 15: Bus Route Optimization using Apache Spark GraphX".
Uses conversational, easy-to-explain language without complex jargon or unit numbers.
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE

def create_presentation():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    blank_layout = prs.slide_layouts[6]

    # Clean Modern Dark Palette
    BG_DARK = RGBColor(15, 23, 42)       # Dark Navy Slate
    BG_CARD = RGBColor(30, 41, 59)       # Card Slate
    CARD_BORDER = RGBColor(51, 65, 85)   # Border Slate
    PRIMARY = RGBColor(37, 99, 235)      # Royal Blue
    ACCENT_CYAN = RGBColor(56, 189, 248) # Sky Blue
    ACCENT_GREEN = RGBColor(52, 211, 153)# Mint Green
    ACCENT_YELLOW = RGBColor(251, 191, 36)# Warm Amber
    ACCENT_RED = RGBColor(248, 113, 113) # Coral Red
    TEXT_LIGHT = RGBColor(248, 250, 252) # Pure White
    TEXT_MUTED = RGBColor(148, 163, 184) # Subtitle Gray
    TEXT_DIM = RGBColor(203, 213, 225)   # Body Text Light Gray

    def set_slide_background(slide):
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
        bg.fill.solid()
        bg.fill.fore_color.rgb = BG_DARK
        bg.line.fill.background()
        return bg

    def add_header(slide, tag_text, title_text, slide_num):
        tag_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(8), Inches(0.35))
        tf = tag_box.text_frame
        p = tf.paragraphs[0]
        p.text = tag_text.upper()
        p.font.size = Pt(11)
        p.font.bold = True
        p.font.color.rgb = ACCENT_CYAN

        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.72), Inches(10.5), Inches(0.6))
        tf_t = title_box.text_frame
        pt = tf_t.paragraphs[0]
        pt.text = title_text
        pt.font.size = Pt(22)
        pt.font.bold = True
        pt.font.color.rgb = TEXT_LIGHT

        num_box = slide.shapes.add_textbox(Inches(11.8), Inches(0.5), Inches(0.8), Inches(0.35))
        pn = num_box.text_frame.paragraphs[0]
        pn.text = f"{slide_num} / 8"
        pn.alignment = PP_ALIGN.RIGHT
        pn.font.size = Pt(11)
        pn.font.color.rgb = TEXT_MUTED

    def add_card(slide, left, top, width, height, title, bg_color=BG_CARD, border_color=CARD_BORDER):
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
        card.fill.solid()
        card.fill.fore_color.rgb = bg_color
        card.line.color.rgb = border_color
        card.line.width = Pt(1.5)

        if title:
            tb = slide.shapes.add_textbox(Inches(left + 0.25), Inches(top + 0.18), Inches(width - 0.5), Inches(0.4))
            p = tb.text_frame.paragraphs[0]
            p.text = title
            p.font.size = Pt(14)
            p.font.bold = True
            p.font.color.rgb = ACCENT_CYAN
        return card

    # =========================================================================
    # SLIDE 1: TITLE SLIDE
    # =========================================================================
    slide1 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide1)

    bar = slide1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.2), Inches(0.15), Inches(3.2))
    bar.fill.solid()
    bar.fill.fore_color.rgb = PRIMARY
    bar.line.fill.background()

    tbox = slide1.shapes.add_textbox(Inches(1.2), Inches(1.1), Inches(11.0), Inches(3.2))
    tf1 = tbox.text_frame
    tf1.word_wrap = True

    p0 = tf1.paragraphs[0]
    p0.text = "INT315 — CLUSTER COMPUTING PROJECT"
    p0.font.size = Pt(12)
    p0.font.bold = True
    p0.font.color.rgb = ACCENT_CYAN

    p1 = tf1.add_paragraph()
    p1.text = "Bus Route Optimization using Apache Spark GraphX"
    p1.font.size = Pt(28)
    p1.font.bold = True
    p1.font.color.rgb = TEXT_LIGHT

    p2 = tf1.add_paragraph()
    p2.text = "Analyzing Delhi's Bus Network, Finding Route Bottlenecks & Proposing Direct Express Links"
    p2.font.size = Pt(15)
    p2.font.color.rgb = TEXT_MUTED

    metas = [
        ("STUDENT NAME", "Aman Singh", ACCENT_GREEN),
        ("COURSE", "INT315 — Cluster Computing", ACCENT_CYAN),
        ("TOOLS USED", "Apache Spark, GraphX, Python", ACCENT_YELLOW),
        ("TARGET CITY", "Delhi Public Bus Network", ACCENT_RED),
    ]
    for i, (lbl, val, col) in enumerate(metas):
        left = 0.8 + (i * 2.95)
        add_card(slide1, left, 4.8, 2.8, 1.8, None)
        tb = slide1.shapes.add_textbox(Inches(left + 0.15), Inches(5.0), Inches(2.5), Inches(1.4))
        tf = tb.text_frame
        tf.word_wrap = True
        p_lbl = tf.paragraphs[0]
        p_lbl.text = lbl
        p_lbl.font.size = Pt(9)
        p_lbl.font.bold = True
        p_lbl.font.color.rgb = TEXT_MUTED

        p_val = tf.add_paragraph()
        p_val.text = val
        p_val.font.size = Pt(13)
        p_val.font.bold = True
        p_val.font.color.rgb = col

    # =========================================================================
    # SLIDE 2: THE PROBLEM (In simple terms)
    # =========================================================================
    slide2 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide2)
    add_header(slide2, "Background & Motivation", "What Problem Are We Solving?", 2)

    add_card(slide2, 0.8, 1.6, 5.6, 5.2, "1. The Public Transit Problem")
    tb2_l = slide2.shapes.add_textbox(Inches(1.05), Inches(2.2), Inches(5.1), Inches(4.3))
    tf2_l = tb2_l.text_frame
    tf2_l.word_wrap = True

    pts2_l = [
        ("Long, Winding Bus Detours:\n", "City bus routes were created decades ago. Instead of straight roads, buses make zig-zag loops through narrow neighborhoods and depot yards, wasting commuters' time."),
        ("Real Example in Delhi:\n", "Going from Connaught Place to Dhaula Kuan currently takes 25 stops and 19 km, circling all the way around Delhi Cantt before reaching its destination!"),
        ("Overcrowded Bus Stops:\n", "Certain key interchange stops handle dozens of overlapping bus routes, creating huge passenger crowds and vehicle traffic bottlenecks.")
    ]
    for i, (bold, text) in enumerate(pts2_l):
        p = tf2_l.paragraphs[0] if i == 0 else tf2_l.add_paragraph()
        p.space_after = Pt(12)
        r_b = p.add_run()
        r_b.text = bold
        r_b.font.bold = True
        r_b.font.size = Pt(11.5)
        r_b.font.color.rgb = ACCENT_RED
        r_t = p.add_run()
        r_t.text = text
        r_t.font.size = Pt(11)
        r_t.font.color.rgb = TEXT_DIM

    add_card(slide2, 6.8, 1.6, 5.7, 5.2, "2. Why Normal Computers Can't Solve It")
    tb2_r = slide2.shapes.add_textbox(Inches(7.05), Inches(2.2), Inches(5.2), Inches(4.3))
    tf2_r = tb2_r.text_frame
    tf2_r.word_wrap = True

    pts2_r = [
        ("City-Scale Data is Huge:\n", "Delhi's bus network has over 8,300 stops and thousands of scheduled trips every single day."),
        ("Normal Tools Freeze / Crash:\n", "Traditional single-machine Python tools (like NetworkX) load everything into a single computer's RAM. On large multi-city networks, they quickly run out of memory."),
        ("Why Cluster Computing is Needed:\n", "We need a distributed system (like Apache Spark) that splits the bus map across multiple CPU cores to analyze all stops and paths in parallel within seconds.")
    ]
    for i, (bold, text) in enumerate(pts2_r):
        p = tf2_r.paragraphs[0] if i == 0 else tf2_r.add_paragraph()
        p.space_after = Pt(12)
        r_b = p.add_run()
        r_b.text = bold
        r_b.font.bold = True
        r_b.font.size = Pt(11.5)
        r_b.font.color.rgb = ACCENT_YELLOW
        r_t = p.add_run()
        r_t.text = text
        r_t.font.size = Pt(11)
        r_t.font.color.rgb = TEXT_DIM

    # =========================================================================
    # SLIDE 3: DATASET DETAILS & THE TWO SOURCES
    # =========================================================================
    slide3 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide3)
    add_header(slide3, "Dataset & Sources", "Dataset Description & Where We Got It", 3)

    # 4 Quick Stat Badges
    dstats = [
        ("8,374", "Total Bus Stops (Vertices)", ACCENT_CYAN),
        ("8,284", "Road Connections (Edges)", ACCENT_GREEN),
        ("195", "Bus Routes Processed", ACCENT_YELLOW),
        ("GTFS Format", "Stops, Routes, Trips Tables", ACCENT_RED),
    ]
    for i, (num, desc, col) in enumerate(dstats):
        left = 0.8 + (i * 2.95)
        add_card(slide3, left, 1.5, 2.8, 1.3, None)
        tb = slide3.shapes.add_textbox(Inches(left + 0.1), Inches(1.55), Inches(2.6), Inches(1.2))
        tf = tb.text_frame
        p_n = tf.paragraphs[0]
        p_n.text = num
        p_n.font.size = Pt(19)
        p_n.font.bold = True
        p_n.font.color.rgb = col
        p_d = tf.add_paragraph()
        p_d.text = desc
        p_d.font.size = Pt(9.5)
        p_d.font.color.rgb = TEXT_MUTED

    # Left: Delhi OTD Portal (Creator)
    add_card(slide3, 0.8, 3.1, 5.6, 3.8, "Source 1: Delhi OTD Portal (Original Creator)")
    tb3_l = slide3.shapes.add_textbox(Inches(1.05), Inches(3.7), Inches(5.1), Inches(3.0))
    tf3_l = tb3_l.text_frame
    tf3_l.word_wrap = True
    p = tf3_l.paragraphs[0]
    p.text = (
        "• What it is: Official Open Transit Data portal created by Delhi Govt & IIIT-Delhi.\n"
        "• Website Link: https://otd.delhi.gov.in\n"
        "• Agency: Delhi Transport Corporation (DTC) & DIMTS.\n\n"
        "• Why we needed a backup:\n"
        "  Live government websites constantly update or change schedules. "
        "  If bus schedules change tomorrow, our project numbers wouldn't match for someone testing our code later!"
    )
    p.font.size = Pt(11)
    p.font.color.rgb = TEXT_DIM

    # Right: Mobility Database (Archive)
    add_card(slide3, 6.8, 3.1, 5.7, 3.8, "Source 2: Mobility Database (Global Archive)")
    tb3_r = slide3.shapes.add_textbox(Inches(7.05), Inches(3.7), Inches(5.2), Inches(3.0))
    tf3_r = tb3_r.text_frame
    tf3_r.word_wrap = True
    p = tf3_r.paragraphs[0]
    p.text = (
        "• What it is: A worldwide public library that archives bus schedules from global cities.\n"
        "• Direct Download Link: https://files.mobilitydatabase.org/mdb-1262/...\n"
        "• Feed ID: mdb-1262 (Permanent Delhi Bus Snapshot)\n\n"
        "• Why we used it in our project:\n"
        "  1. Permanent Copy: Freezes the exact dataset in time.\n"
        "  2. 100% Reliable: Anyone can download the exact same files and get the exact same results anytime."
    )
    p.font.size = Pt(11)
    p.font.color.rgb = TEXT_DIM

    # =========================================================================
    # SLIDE 4: TECHNOLOGIES USED & WHY
    # =========================================================================
    slide4 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide4)
    add_header(slide4, "Tools & Frameworks", "Technologies Used to Build This Project", 4)

    techs = [
        ("Apache Spark 3.5", "Cluster Computing Engine", [
            "Runs data processing across all computer cores at the same time.",
            "Keeps data in RAM (in-memory) instead of slow hard disk reads.",
            "Fast, distributed, and handles big datasets effortlessly."
        ], ACCENT_CYAN),
        ("Spark GraphX (Scala)", "Distributed Graph Library", [
            "Turns bus stops into nodes (vertices) and roads into links (edges).",
            "Calculates the busiest bus stops in Delhi automatically.",
            "Finds the fastest bus path across 8,300 stops in under 4 seconds."
        ], ACCENT_GREEN),
        ("PySpark Machine Learning", "Predictive Modeling", [
            "Groups bus stops into 5 regional zones (K-Means clustering).",
            "Predicts exact travel times for commuters (Linear Regression).",
            "Evaluates accuracy using standard scores (R2, RMSE)."
        ], ACCENT_YELLOW),
        ("Python & Interactive Maps", "Visualization Tools", [
            "Preprocesses raw GTFS bus schedule files into clean tables.",
            "Calculates real-world road distances using GPS coordinates.",
            "Generates an interactive city map (Folium / OpenStreetMap)."
        ], ACCENT_RED),
    ]

    for i, (name, role, points, col) in enumerate(techs):
        left = 0.8 + (i * 2.95)
        add_card(slide4, left, 1.6, 2.8, 5.2, name)
        tb = slide4.shapes.add_textbox(Inches(left + 0.15), Inches(2.2), Inches(2.5), Inches(4.3))
        tf = tb.text_frame
        tf.word_wrap = True

        p_r = tf.paragraphs[0]
        p_r.text = role
        p_r.font.size = Pt(10)
        p_r.font.bold = True
        p_r.font.color.rgb = col
        p_r.space_after = Pt(12)

        for pt in points:
            p = tf.add_paragraph()
            p.text = f"• {pt}"
            p.font.size = Pt(10)
            p.font.color.rgb = TEXT_DIM
            p.space_after = Pt(8)

    # =========================================================================
    # SLIDE 5: HOW WE SOLVED THE PROBLEM (Methodology)
    # =========================================================================
    slide5 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide5)
    add_header(slide5, "Implementation Workflow", "How We Solved the Problem (Step-by-Step)", 5)

    workflow_steps = [
        ("Step 1: Clean Raw Bus Timetables", "We took raw Delhi bus files (stops and timings). Python linked every stop to the next stop along each bus trip, calculated real road distances with GPS, and created clean tables."),
        ("Step 2: Build the Distributed Bus Map", "Apache Spark loaded the data into GraphX. Bus stops became 'nodes' and bus roads became 'edges'. The entire map was stored in Spark's high-speed memory."),
        ("Step 3: Find the Busiest Hubs & Detours", "GraphX counted how many bus routes pass through each stop. Connaught Place came out as #1. Spark then searched for the shortest path and spotted the 25-stop detour to Dhaula Kuan."),
        ("Step 4: Add Express Link & Measure Gains", "We proposed a new direct express link (Route 9999). Spark re-ran the path calculation to prove how much travel distance, transfers, and time commuters save.")
    ]

    for i, (title, text) in enumerate(workflow_steps):
        left = 0.8 + (i * 2.95)
        add_card(slide5, left, 1.6, 2.8, 2.4, title)
        tb = slide5.shapes.add_textbox(Inches(left + 0.15), Inches(2.25), Inches(2.5), Inches(1.65))
        tf = tb.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = text
        p.font.size = Pt(9.5)
        p.font.color.rgb = TEXT_DIM

    # Bottom Explanation of the Pregel Shortest Path Algorithm
    add_card(slide5, 0.8, 4.3, 11.7, 2.5, "How Spark Finds the Shortest Path (Pregel Algorithm Explained Simply)")
    tb5_b = slide5.shapes.add_textbox(Inches(1.05), Inches(4.9), Inches(11.2), Inches(1.8))
    tf5_b = tb5_b.text_frame
    tf5_b.word_wrap = True

    pregel_simple = (
        "• Step-by-Step Messaging: Imagine every bus stop is a person with a phone.\n"
        "• Finding the Fastest Way: The starting stop (Connaught Place) texts all connected stops: 'I am 0 km away'.\n"
        "• Passing the Message: Each neighboring stop adds its road distance and passes the text to its neighbors.\n"
        "• Remembering the Best Path: If a stop receives two texts with different distances, it keeps the shorter one and forgets the longer one.\n"
        "• Done in Seconds: Spark runs this across all CPU cores simultaneously, finding the absolute best route across 8,300 stops in under 4 seconds!"
    )
    p = tf5_b.paragraphs[0]
    p.text = pregel_simple
    p.font.size = Pt(11)
    p.font.color.rgb = TEXT_DIM

    # =========================================================================
    # SLIDE 6: RESULTS & IMPACT (Before vs. After)
    # =========================================================================
    slide6 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide6)
    add_header(slide6, "Key Findings & Numbers", "Results: Before vs. After Adding the Express Corridor", 6)

    # Left: Comparison Table
    add_card(slide6, 0.8, 1.6, 6.8, 5.2, "Corridor: Connaught Place to Dhaula Kuan")
    tb6_l = slide6.shapes.add_textbox(Inches(1.05), Inches(2.2), Inches(6.3), Inches(4.3))
    tf6_l = tb6_l.text_frame
    tf6_l.word_wrap = True

    p = tf6_l.paragraphs[0]
    p.text = "By adding a single direct express bus corridor (Route 9999), we eliminated the winding detour:"
    p.font.size = Pt(11)
    p.font.color.rgb = TEXT_MUTED
    p.space_after = Pt(10)

    rows = [
        ("Metric", "Before (Detour)", "After (Express)", "What We Saved"),
        ("Travel Distance", "18.88 km", "9.57 km", "-9.32 km (49.3% Shorter!)"),
        ("Bus Stops / Hops", "25 stops", "1 direct stop", "-24 stops (96% Fewer Stops!)"),
        ("Commuter Travel Time", "64.3 mins", "33.3 mins", "~31 mins Saved (48% Faster!)"),
        ("Calculation Time", "3.6 seconds", "3.6 seconds", "Instant Spark Response")
    ]
    for r_i, (c1, c2, c3, c4) in enumerate(rows):
        p = tf6_l.add_paragraph()
        p.space_after = Pt(8)
        r1 = p.add_run()
        r1.text = f"{c1:22}"
        r1.font.bold = True
        r1.font.size = Pt(10.5)
        r1.font.color.rgb = ACCENT_CYAN if r_i == 0 else TEXT_LIGHT

        r2 = p.add_run()
        r2.text = f"{c2:18}"
        r2.font.size = Pt(10.5)
        r2.font.color.rgb = ACCENT_RED if r_i > 0 else ACCENT_CYAN

        r3 = p.add_run()
        r3.text = f"{c3:18}"
        r3.font.size = Pt(10.5)
        r3.font.color.rgb = ACCENT_GREEN if r_i > 0 else ACCENT_CYAN

        r4 = p.add_run()
        r4.text = f"{c4}"
        r4.font.bold = True
        r4.font.size = Pt(10.5)
        r4.font.color.rgb = ACCENT_YELLOW if r_i > 0 else ACCENT_CYAN

    # Right: Top 5 Busiest Hubs
    add_card(slide6, 7.9, 1.6, 4.6, 5.2, "Delhi's Top 5 Busiest Transit Hubs")
    tb6_r = slide6.shapes.add_textbox(Inches(8.15), Inches(2.2), Inches(4.1), Inches(4.3))
    tf6_r = tb6_r.text_frame
    tf6_r.word_wrap = True

    hubs_info = [
        ("1. Super Bazar / Connaught Place", "16 bus routes | 30 connections (Delhi's #1 Hub)"),
        ("2. Sadhu Vaswani Marg / Pusa Rd", "13 bus routes | 26 connections"),
        ("3. Karol Bagh Metro Station", "13 bus routes | 26 connections"),
        ("4. Nauroji Nagar (Ring Road)", "13 bus routes | 26 connections"),
        ("5. Dhaula Kuan Interchange", "13 bus routes | 25 connections (Major Gateway)")
    ]
    for name, stat in hubs_info:
        p = tf6_r.paragraphs[0] if tf6_r.paragraphs[0].text == "" else tf6_r.add_paragraph()
        p.space_after = Pt(8)
        rn = p.add_run()
        rn.text = f"{name}\n"
        rn.font.bold = True
        rn.font.size = Pt(11)
        rn.font.color.rgb = TEXT_LIGHT
        rs = p.add_run()
        rs.text = f"   {stat}"
        rs.font.size = Pt(10)
        rs.font.color.rgb = ACCENT_CYAN

    p_summary = tf6_r.add_paragraph()
    p_summary.space_before = Pt(10)
    p_summary.text = "★ What this proves to the teacher:\nSpark GraphX successfully identified where the crowd is highest and showed how one smart route change can cut travel time in half."
    p_summary.font.size = Pt(9.5)
    p_summary.font.color.rgb = ACCENT_YELLOW

    # =========================================================================
    # SLIDE 7: MACHINE LEARNING (K-Means & Linear Regression)
    # =========================================================================
    slide7 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide7)
    add_header(slide7, "Predictive Machine Learning", "Machine Learning: Grouping Bus Stops & Predicting Travel Times", 7)

    # Left: K-Means
    add_card(slide7, 0.8, 1.6, 5.6, 5.2, "1. Grouping Stops (K-Means Clustering)")
    tb7_l = slide7.shapes.add_textbox(Inches(1.05), Inches(2.2), Inches(5.1), Inches(4.3))
    tf7_l = tb7_l.text_frame
    tf7_l.word_wrap = True

    km_points = (
        "• What it does in simple terms:\n"
        "  Instead of looking at 8,300 stops individually, Machine Learning automatically grouped all stops into 5 major regional zones based on their GPS coordinates.\n\n"
        "• The 5 Regional Hub Zones Discovered:\n"
        "  - Zone 0 (West Delhi / Dwarka): 1,611 stops\n"
        "  - Zone 1 (East Delhi / Trans-Yamuna): 1,333 stops\n"
        "  - Zone 2 (South Delhi / AIIMS): 1,817 stops\n"
        "  - Zone 3 (Central Delhi / Connaught Place): 2,064 stops\n"
        "  - Zone 4 (North Delhi / Rohini): 1,546 stops\n\n"
        "• Model Quality:\n"
        "  Achieved a Silhouette Score of 0.52, confirming clean, well-separated geographic transit zones."
    )
    p = tf7_l.paragraphs[0]
    p.text = km_points
    p.font.size = Pt(10.5)
    p.font.color.rgb = TEXT_DIM

    # Right: Linear Regression
    add_card(slide7, 6.8, 1.6, 5.7, 5.2, "2. Predicting Travel Times (Linear Regression)")
    tb7_r = slide7.shapes.add_textbox(Inches(7.05), Inches(2.2), Inches(5.2), Inches(4.3))
    tf7_r = tb7_r.text_frame
    tf7_r.word_wrap = True

    lr_points = (
        "• What it does in simple terms:\n"
        "  Predicts how many minutes a bus trip will take based on the road distance and stop waiting times.\n\n"
        "• How Accurate is the Model?\n"
        "  - R² Score: 0.9942 (Almost 99.4% accurate fit!)\n"
        "  - Average Error (RMSE): Only ~0.34 minutes!\n\n"
        "• Real Commuter Time Savings (CP -> Dhaula Kuan):\n"
        "  - Current Detour (18.88 km): 64.3 minutes\n"
        "  - Proposed Express (9.57 km): 33.3 minutes\n"
        "  - Time Saved: ~31 minutes saved per passenger on every single trip!"
    )
    p = tf7_r.paragraphs[0]
    p.text = lr_points
    p.font.size = Pt(10.5)
    p.font.color.rgb = TEXT_DIM

    # =========================================================================
    # SLIDE 8: SUMMARY & LIVE DEMO
    # =========================================================================
    slide8 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide8)
    add_header(slide8, "Conclusion & Demo", "Summary & How to Demonstrate It to the Teacher", 8)

    add_card(slide8, 0.8, 1.6, 3.6, 5.2, "1. What We Achieved")
    tb8_1 = slide8.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(3.2), Inches(4.3))
    tf8_1 = tb8_1.text_frame
    tf8_1.word_wrap = True
    p = tf8_1.paragraphs[0]
    p.text = (
        "• Solved a Real Issue:\n"
        "Identified a 25-stop winding bottleneck and mathematically proved a direct express corridor saves 49% distance and 31 minutes.\n\n"
        "• Big Data Scalability:\n"
        "Used Apache Spark GraphX to analyze an entire state's transit network in under 4 seconds using cluster parallelism."
    )
    p.font.size = Pt(11)
    p.font.color.rgb = TEXT_DIM

    add_card(slide8, 4.8, 1.6, 3.8, 5.2, "2. Key Answers for Teacher")
    tb8_2 = slide8.shapes.add_textbox(Inches(5.0), Inches(2.2), Inches(3.4), Inches(4.3))
    tf8_2 = tb8_2.text_frame
    tf8_2.word_wrap = True
    p = tf8_2.paragraphs[0]
    p.text = (
        "• 'Why Spark?'\n"
        "Because regular Python tools crash on large graphs; Spark stores graph data in distributed RAM.\n\n"
        "• 'Why Two Data Sources?'\n"
        "Delhi OTD is the original creator; Mobility Database is the permanent archive for reproducibility.\n\n"
        "• 'What ML is Used?'\n"
        "K-Means to group stops, Linear Regression to predict travel times."
    )
    p.font.size = Pt(10.5)
    p.font.color.rgb = TEXT_DIM

    add_card(slide8, 8.9, 1.6, 3.6, 5.2, "3. Commands to Show Live")
    tb8_3 = slide8.shapes.add_textbox(Inches(9.1), Inches(2.2), Inches(3.2), Inches(4.3))
    tf8_3 = tb8_3.text_frame
    tf8_3.word_wrap = True
    p = tf8_3.paragraphs[0]
    p.text = (
        "Run in Terminal:\n\n"
        "1. Run Spark GraphX Job:\n"
        "spark-submit --class busroute.BusRouteApp --master 'local[*]' target/busroute-graphx.jar data/stops.csv data/edges.csv output\n\n"
        "2. Run Machine Learning:\n"
        "python3 spark_ml_analysis.py\n\n"
        "3. Show Interactive Map:\n"
        "open viz/map.html\n\n"
        "4. Show Full PDF Report:\n"
        "open Project_15_Bus_Route_Optimization_Report.pdf"
    )
    p.font.size = Pt(9.5)
    p.font.color.rgb = ACCENT_CYAN

    output_pptx = "Project_15_Bus_Route_Optimization_Presentation.pptx"
    prs.save(output_pptx)
    print(f"[SUCCESS] Easy-to-explain presentation generated: {output_pptx} (8 slides, 16:9 widescreen)")

if __name__ == "__main__":
    create_presentation()
