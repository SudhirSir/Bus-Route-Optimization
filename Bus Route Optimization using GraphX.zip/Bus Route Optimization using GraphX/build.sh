#!/usr/bin/env bash
# ============================================================================
# build.sh - Compiles BusRouteApp.scala into target/busroute-graphx.jar
# Uses the Scala compiler included inside Spark's jars directory.
# ============================================================================

set -e

SPARK_HOME="${SPARK_HOME:-/opt/spark}"
echo "[*] Using SPARK_HOME: $SPARK_HOME"

mkdir -p target bin

echo "[*] Compiling src/main/scala/busroute/BusRouteApp.scala..."
java -cp "$SPARK_HOME/jars/*" scala.tools.nsc.Main -usejavacp -d bin src/main/scala/busroute/BusRouteApp.scala

echo "[*] Packaging JAR into target/busroute-graphx.jar..."
jar cvf target/busroute-graphx.jar -C bin .

echo "============================================================================"
echo "[SUCCESS] Built target/busroute-graphx.jar successfully!"
echo "Run with:"
echo '  spark-submit --class busroute.BusRouteApp --master "local[*]" target/busroute-graphx.jar data/stops.csv data/edges.csv output'
echo "============================================================================"
