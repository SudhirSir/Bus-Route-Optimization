name := "bus-route-optimization-graphx"
version := "1.0"
scalaVersion := "2.12.18"

val sparkVersion = "3.5.0"

// Spark dependencies
// When running with spark-submit, spark-core and spark-sql are provided by the Spark cluster runtime.
// spark-graphx is included here to ensure all GraphX classes and Pregel operators are packaged or available.
libraryDependencies ++= Seq(
  "org.apache.spark" %% "spark-core"   % sparkVersion % "provided",
  "org.apache.spark" %% "spark-sql"    % sparkVersion % "provided",
  "org.apache.spark" %% "spark-graphx" % sparkVersion
)

// Fork execution to provide a clean JVM for Spark operations
fork := true
