# Project 15: Bus Route Optimization using Apache Spark GraphX
## Complete Viva Defense Guide, Core Concepts & Comprehensive Q&A

**Course:** INT315 – Cluster Computing  
**Student Name:** Aman Singh  
**Topic:** Large-Scale Urban Transit Network Analysis & Topological Route Optimization  
**Framework:** Apache Spark GraphX (Scala), PySpark MLlib, and Python GIS  

---

## 1. High-Level Executive Summary (The 30-Second Elevator Pitch)

> *"My project uses **Apache Spark GraphX** in **Scala** to analyze and optimize Delhi's public bus transit network consisting of over **8,374 bus stops** and **8,284 route connections**.*
>
> *Using distributed cluster algorithms like **Degree Centrality** and **Pregel Bulk Synchronous Parallel (BSP) Shortest Path**, we discovered a severe topological bottleneck between Delhi's two biggest hubs—**Connaught Place** and **Dhaula Kuan**—where buses currently take a circuitous **25-hop, 18.88 km detour** winding through Delhi Cantt.*
>
> *We proposed a direct express corridor (**Route 9999**) and mathematically proved across distributed executors that this single infrastructure addition cuts commute distance by **49.3%** (from 18.88 km down to 9.57 km), eliminates **24 unnecessary transfers (96% reduction)**, and saves commuters **~31 minutes per trip** as predicted by our **PySpark MLlib** regression model."*

---

## 2. Core Methodologies & Technologies Explained Simply

Every technology in this project was chosen to solve a specific engineering bottleneck that traditional single-machine tools cannot handle:

### 2.1 Graph Theory Modeling: Vertices ($V$) and Edges ($E$)
* **Concept:** A graph is a mathematical structure composed of points (nodes/vertices) connected by lines (edges).
* **In this Project:** 
  - **Vertices ($V$):** Physical bus stops represented by 64-bit Long IDs with properties: `(Stop Name, Latitude, Longitude)`. Total = **8,374 vertices**.
  - **Edges ($E$):** Directed transit corridors between consecutive stops along scheduled bus routes: `(Source ID, Destination ID, Route ID, Road Distance in km)`. Total = **8,284 edges**.
* **Why it matters:** Modeling transit as a directed property graph allows us to use distributed graph algorithms instead of slow relational table scans.

### 2.2 Great-Circle Haversine Formula with Empirical Road Detour Factor ($1.3\times$)
* **Concept:** Calculating the spherical surface distance between two GPS coordinates $(\phi_1, \lambda_1)$ and $(\phi_2, \lambda_2)$ using earth's radius ($R = 6,371\text{ km}$):
  $$d = 2R \arcsin \left(\sqrt{\sin^2\left(\frac{\Delta \phi}{2}\right) + \cos(\phi_1)\cos(\phi_2)\sin^2\left(\frac{\Delta \lambda}{2}\right)}\right)$$
* **The $1.3\times$ Road Factor:** Buses cannot fly in a straight line like airplanes. Empirical urban transportation studies show that real street grids in high-density metropolitan areas like Delhi have an average winding factor of approximately **$1.3\times$** straight-line flight:
  $$\text{distance\_km} = d \times 1.3$$

### 2.3 Normalized Degree Centrality (Transit Congestion Proxy)
* **Concept:** A measure of how connected a node is in a network. In a directed graph with $N$ vertices:
  $$C_D(v) = \frac{\text{deg}_{\text{in}}(v) + \text{deg}_{\text{out}}(v)}{2 \cdot (N - 1)}$$
* **Why Normalization Matters:** Dividing by $2(N-1)$ bounds centrality strictly between $0.0$ and $1.0$, allowing mathematical comparability across different city networks.
* **In this Project:** In the absence of live ticket-swipe telemetry, degree centrality measures **structural transfer pressure**. It proved **Super Bazar / Connaught Place (ID 2186)** is Delhi's undisputed #1 hub (Degree: 30, Distinct Routes: 16).

### 2.4 Apache Spark & In-Memory Resilient Distributed Datasets (RDDs)
* **Concept:** Spark distributes data across memory (RAM) across cluster nodes instead of reading and writing temporary results to hard drives (like Hadoop MapReduce).
* **In this Project:**
  - `VertexRDD`: Distributed collection of stop metadata partitioned across CPU cores.
  - `EdgeRDD`: Distributed collection of distance-weighted route segments.
  - `graph.cache()`: Caches the partitioned graph in memory (`MEMORY_ONLY`). Because iterative graph algorithms iterate over the same graph repeatedly, caching avoids rebuilding the RDD lineage from CSV on every iteration.

### 2.5 Vertex-Cut Partitioning (`EdgePartition2D`)
* **Concept:** Unlike traditional databases that split tables row-by-row, GraphX uses **vertex-cut partitioning**. Edges are distributed evenly across worker partitions, while high-degree vertices (like Connaught Place) are replicated across workers only when necessary.
* **Benefit:** Bounded replication guarantees that vertex replication is at most $2\sqrt{P} - 1$ where $P$ is the number of worker partitions, avoiding network communication bottlenecks.

### 2.6 Pregel Bulk Synchronous Parallel (BSP) Shortest Path Engine
* **Concept:** An iterative, message-passing graph processing model originally created by Google.
* **How it works step-by-step:**
  1. **Initialization:** Starting node (Connaught Place) is initialized with distance `0.0`; all other 8,373 vertices start with distance `Infinity`.
  2. **Message Generation (`sendMsg`):** In each iteration (superstep), active vertices calculate `(current_distance + edge_distance)` and send distance update messages across outgoing edges.
  3. **Message Combiner (`mergeMsg`):** If a stop receives multiple messages from different paths during the same superstep, executors merge them locally using `min(msgA, msgB)`, reducing network shuffle.
  4. **Vertex Program (`vprog`):** If the received message is smaller than the vertex's current distance, the vertex updates its state and becomes active for the next superstep.
  5. **Halting Condition:** The algorithm halts automatically when no new distance relaxation messages are active across the entire cluster.
* **Runtime:** Runs in **3.6 seconds** across all 8,374 vertices on Spark!

### 2.7 Machine Learning Models (PySpark MLlib)
* **Unsupervised Learning — K-Means Spatial Clustering ($k=5$):**
  - Uses `VectorAssembler` on coordinates `[lat, lon]` to automatically discover 5 natural regional transit zones (West, East, South, Central, North Delhi) with a **Silhouette Score of 0.5215**.
* **Supervised Learning — Linear Regression Travel Time Predictor:**
  - Models commuter travel time: $\text{Travel Time} = 3.3254 \times \text{distance} + 1.4995$.
  - Evaluation Metrics: **$R^2 = 0.9942$** (99.4% accuracy), **$\text{RMSE} = 0.34\text{ mins}$**, **$\text{MAE} = 0.29\text{ mins}$**.
  - Proves that Route 9999 saves commuters **~31 minutes per trip (48.2% faster commute)**.

---

## 3. The Dataset: Two Sources Explained

* **Source 1: Delhi Open Transit Data (OTD) Portal (`otd.delhi.gov.in`)**
  - **Role:** Official original creator. Managed by Department of Transport (Govt. of NCT of Delhi) and IIIT-Delhi.
  - **Challenge:** Live government websites frequently change, update, or overwrite timetables, meaning two people running code on different months might get different results.
* **Source 2: Mobility Database (`mobilitydatabase.org` / Feed ID: `mdb-1262`)**
  - **Role:** Permanent global digital archive.
  - **Purpose:** Acts as a canonical "frozen snapshot" of Delhi's bus feed. Provides direct, permanent access without login or session timeouts, guaranteeing **100% academic reproducibility**.

---

## 4. Comprehensive Viva Questions & Model Answers

### Q1: What is the main objective of your project?
**Answer:** The objective is to build a distributed cluster computing pipeline using **Apache Spark GraphX** to model Delhi's metropolitan bus network, detect inefficient winding routes between major hubs using iterative Pregel shortest-path algorithms, and quantitatively evaluate the impact of proposed direct express corridors.

---

### Q2: Why did you use Apache Spark instead of standard Python libraries like NetworkX?
**Answer:** 
1. **Memory Scalability:** NetworkX runs strictly in single-machine RAM and is single-threaded. While it works for small demo graphs, it crashes with out-of-memory errors on national, state-wide, or multimodal transit networks with millions of edges.
2. **Cluster Parallelism:** Apache Spark partitions the graph across all available CPU cores and worker nodes, allowing distributed message passing.
3. **In-Memory Speed:** Spark RDDs cache the graph in memory, allowing iterative shortest path algorithms to converge across 8,374 nodes in under 4 seconds.

---

### Q3: What is the difference between Hadoop MapReduce and Spark for this project?
**Answer:** Graph algorithms like Pregel are **iterative**—they run multiple consecutive rounds (supersteps) on the same graph.
- **Hadoop MapReduce:** Writes all intermediate outputs back to physical hard disks (HDFS) at the end of every single Map and Reduce phase, causing massive disk I/O bottlenecks.
- **Apache Spark:** Retains intermediate RDD states in distributed RAM memory (`graph.cache()`), executing iterative supersteps up to 100× faster than MapReduce.

---

### Q4: Explain the Pregel algorithm and how it is used in your project.
**Answer:** Pregel is a Bulk Synchronous Parallel (BSP) message-passing graph framework.
- Vertices start with infinite distance except the origin hub (Connaught Place = 0).
- In each superstep, active vertices send `current_dist + edge_weight` messages to their neighbors.
- If a vertex receives a smaller distance than its current value, it relaxes its shortest distance and continues propagating.
- It converges when no shorter path can be found. In our project, Pregel identified that traveling to Dhaula Kuan takes 25 hops and 18.88 km, which was reduced to 1 hop and 9.57 km after adding Route 9999.

---

### Q5: Why is Degree Centrality used as a congestion proxy?
**Answer:** Real-time electronic ticketing and passenger turnstile counts are proprietary and not publicly available in GTFS feeds. However, graph theory demonstrates that stops with high in-degree and out-degree serve as the primary convergence points for overlapping bus routes. Therefore, **Degree Centrality serves as an accurate structural proxy** for hub passenger volume and transfer choke points.

---

### Q6: What did your Degree Centrality analysis discover?
**Answer:** It identified **Super Bazar / Connaught Place (Stop ID 2186)** as Delhi's #1 busiest transit hub with a total degree of 30 connections across 16 distinct bus routes, followed by Pusa Road, Karol Bagh Metro Station, and Dhaula Kuan Interchange.

---

### Q7: What specific route bottleneck did you solve?
**Answer:** The corridor between **Connaught Place** and **Dhaula Kuan**. Commuters traveling on existing bus routes were forced into a 25-hop, 18.88 km loop winding through the Delhi Cantonment before circling back to Dhaula Kuan. We proposed **Route 9999**, a direct express corridor along Sardar Patel Marg, cutting travel distance by **49.3% (9.57 km)**, reducing stops by **96% (1 direct hop)**, and saving **~31 minutes per trip**.

---

### Q8: What is `graph.cache()` and what happens if you don't use it?
**Answer:** `graph.cache()` instructs Spark to keep the `VertexRDD` and `EdgeRDD` in executor RAM memory (`MEMORY_ONLY`). If we do not cache the graph, Spark's lazy evaluation will re-read and re-parse the CSV files and reconstruct the RDD lineage from scratch on *every single iteration* of Pregel, causing massive performance degradation.

---

### Q9: What Machine Learning models did you use and what were the results?
**Answer:** Using **PySpark MLlib**, we implemented:
1. **K-Means Spatial Clustering ($k=5$):** Clustered the 8,374 bus stops into 5 geographic transit zones (West, East, South, Central, North Delhi) with a **Silhouette Score of 0.5215**.
2. **Linear Regression Travel Time Model:** Predicted commuter travel time based on distance and stop dwell delays:
   - **$R^2$ Score:** 0.9942 (exceptional goodness of fit)
   - **RMSE:** 0.34 minutes
   - **MAE:** 0.29 minutes
   - Predicted commuter time savings of **30.96 minutes (48.2% faster commute)** on Route 9999.

---

### Q10: Why are two dataset links mentioned in your project?
**Answer:**
1. **Delhi OTD Portal (`otd.delhi.gov.in`):** The original source created by the Delhi Government and IIIT-Delhi.
2. **The Mobility Database (`mobilitydatabase.org` / Feed ID: `mdb-1262`):** An international digital archive that permanently preserves transit schedules worldwide. We used it because live government portals frequently overwrite timetables; using the cataloged snapshot guarantees that our experimental results (8,374 nodes, 49.3% reduction) are **100% reproducible** by anyone testing our project.

---

### Q11: What are the project limitations?
**Answer:**
1. **Topological vs. Live Passenger Counts:** Centrality measures connectivity, not live turnstile crowd numbers.
2. **Scheduled vs. Live GPS Delays:** Static GTFS reflects planned timetables rather than real-time traffic jams or vehicle breakdowns.
3. **Empirical Distance Factor:** The 1.3× Haversine factor is an accurate metropolitan average, but specific winding street geometries may vary.

---

## 5. Live Demonstration Commands Quick Reference

| Action | Terminal Command | What It Proves to the Teacher |
| :--- | :--- | :--- |
| **1. Run Spark GraphX** | `spark-submit --class busroute.BusRouteApp --master "local[*]" target/busroute-graphx.jar data/stops.csv data/edges.csv output` | Demonstrates distributed graph construction (8,374 nodes, 8,284 edges), degree centrality rankings, and Pregel shortest-path execution in 3.6s. |
| **2. Run Spark MLlib** | `python3 spark_ml_analysis.py` | Runs K-Means zone clustering ($k=5$) and Linear Regression travel-time forecasting ($R^2 = 0.9942$, 31 mins saved). |
| **3. Open GIS Map** | `open viz/map.html` | Opens interactive browser map showing red detour vs. green express link on Delhi road network. |
| **4. Open Report** | `open Project_15_Bus_Route_Optimization_Report.pdf` | Shows the complete 19-page academic capstone report. |
