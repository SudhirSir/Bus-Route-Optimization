#!/usr/bin/env python3
"""
preprocess_gtfs.py
==================
Step 0 of "Project 15: Bus Route Optimization using GraphX".

This script processes raw General Transit Feed Specification (GTFS) bus feeds
(e.g., Delhi Transport Corporation / DIMTS open data) and produces two clean CSVs
ready for Apache Spark GraphX graph creation:

  1. data/stops.csv : stop_id,stop_name,lat,lon
  2. data/edges.csv : src_id,dst_id,route_id,distance_km

Key Processing Rules:
  - Sequences stops along each trip in stop_times.txt into consecutive pairs (edges).
  - Joins trips.txt to link each trip to its route_id.
  - Deduplicates (src_id, dst_id, route_id) edges.
  - Computes road network distance using Haversine * 1.3 (empirical road winding factor).
  - Maps any arbitrary GTFS stop_id strings to numeric 64-bit Long integers (required by GraphX).
  - Drops invalid edges referring to stops missing from stops.txt.
  - Supports `--max-routes N` to enable rapid laptop-scale testing or full-scale runs.
  - Automatically fetches the official Delhi GTFS dataset if not present locally.

Dataset Source:
  Delhi Transport Corporation (DTC) & DIMTS GTFS static feed
  Mobility Database ID: mdb-1262
  Direct download: https://files.mobilitydatabase.org/mdb-1262/mdb-1262-202406071502/mdb-1262-202406071502.zip
"""

import os
import sys
import argparse
import zipfile
import urllib.request
import pandas as pd
import numpy as np

# Official archive download URL from Mobility Database catalog
GTFS_DOWNLOAD_URL = (
    "https://files.mobilitydatabase.org/mdb-1262/mdb-1262-202406071502/mdb-1262-202406071502.zip"
)


def haversine_vectorized(lat1: np.ndarray, lon1: np.ndarray, lat2: np.ndarray, lon2: np.ndarray) -> np.ndarray:
    """
    Computes the great-circle distance between pairs of coordinates on Earth (in km)
    using the Haversine formula, vectorized with NumPy for maximum performance.
    """
    R = 6371.0  # Earth's mean radius in kilometers

    phi1 = np.radians(lat1)
    phi2 = np.radians(lat2)
    delta_phi = np.radians(lat2 - lat1)
    delta_lambda = np.radians(lon2 - lon1)

    a = np.sin(delta_phi / 2.0) ** 2 + np.cos(phi1) * np.cos(phi2) * np.sin(delta_lambda / 2.0) ** 2
    c = 2.0 * np.arctan2(np.sqrt(a), np.sqrt(1.0 - a))
    return R * c


def ensure_gtfs_extracted(raw_dir: str = "gtfs_raw", zip_file: str = "delhi_gtfs.zip") -> str:
    """
    Ensures that GTFS text files are downloaded and extracted to `raw_dir`.
    """
    required_files = ["stops.txt", "trips.txt", "stop_times.txt"]
    all_present = os.path.exists(raw_dir) and all(
        os.path.exists(os.path.join(raw_dir, f)) for f in required_files
    )

    if all_present:
        print(f"[OK] Found extracted GTFS files in '{raw_dir}'")
        return raw_dir

    # If zip is not present, download it
    if not os.path.exists(zip_file):
        print(f"[*] Downloading Delhi GTFS feed from:\n    {GTFS_DOWNLOAD_URL}")
        try:
            req = urllib.request.Request(
                GTFS_DOWNLOAD_URL,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"},
            )
            with urllib.request.urlopen(req) as resp, open(zip_file, "wb") as out_file:
                total_bytes = int(resp.headers.get("Content-Length", 0))
                downloaded = 0
                chunk_size = 65536
                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break
                    out_file.write(chunk)
                    downloaded += len(chunk)
                    if total_bytes > 0:
                        percent = (downloaded / total_bytes) * 100
                        print(f"\r    Progress: {downloaded / (1024*1024):.2f} MB / {total_bytes / (1024*1024):.2f} MB ({percent:.1f}%)", end="")
            print("\n[OK] Download complete.")
        except Exception as e:
            print(f"\n[ERROR] Automated download failed: {e}")
            print("Please manually download the GTFS zip from:")
            print(f"    {GTFS_DOWNLOAD_URL}")
            print(f"and place the zip file as '{zip_file}' or extract to '{raw_dir}'.")
            sys.exit(1)

    print(f"[*] Extracting '{zip_file}' into '{raw_dir}'...")
    os.makedirs(raw_dir, exist_ok=True)
    with zipfile.ZipFile(zip_file, "r") as zf:
        zf.extractall(raw_dir)
    print(f"[OK] Extracted successfully to '{raw_dir}'.")
    return raw_dir


def preprocess(raw_dir: str, output_dir: str, max_routes: int = None, route_ids: list = None):
    """
    Executes the GTFS preprocessing pipeline.
    """
    os.makedirs(output_dir, exist_ok=True)
    stops_file = os.path.join(raw_dir, "stops.txt")
    trips_file = os.path.join(raw_dir, "trips.txt")
    stop_times_file = os.path.join(raw_dir, "stop_times.txt")

    # 1. Load stops
    print(f"[*] Reading stops from '{stops_file}'...")
    stops_df = pd.read_csv(stops_file, usecols=["stop_id", "stop_name", "stop_lat", "stop_lon"])
    stops_df.dropna(subset=["stop_lat", "stop_lon"], inplace=True)
    # Ensure stop_id is string for consistent mapping
    stops_df["raw_stop_id"] = stops_df["stop_id"].astype(str)

    # Deterministic mapping: GTFS stop_id -> 64-bit Long numeric ID
    unique_stops = sorted(stops_df["raw_stop_id"].unique())
    stop_id_map = {sid: idx for idx, sid in enumerate(unique_stops)}
    stops_df["stop_id"] = stops_df["raw_stop_id"].map(stop_id_map)

    # 2. Load trips and handle route filtering
    print(f"[*] Reading trips from '{trips_file}'...")
    trips_df = pd.read_csv(trips_file, usecols=["trip_id", "route_id"])

    # Apply route filtering if requested
    if route_ids:
        trips_df = trips_df[trips_df["route_id"].isin(route_ids)]
        print(f"    Filtered to specified route IDs: {route_ids} ({len(trips_df)} trips)")
    elif max_routes is not None and max_routes > 0:
        available_routes = trips_df["route_id"].unique()[:max_routes]
        trips_df = trips_df[trips_df["route_id"].isin(available_routes)]
        print(f"    Filtered to first {max_routes} routes ({len(trips_df)} trips)")

    active_trip_to_route = dict(zip(trips_df["trip_id"], trips_df["route_id"]))
    active_trip_set = set(active_trip_to_route.keys())

    # 3. Read stop_times in chunks
    print(f"[*] Reading stop times from '{stop_times_file}' in chunks...")
    chunks = []
    chunk_size = 100000
    for chunk in pd.read_csv(stop_times_file, chunksize=chunk_size, usecols=["trip_id", "stop_id", "stop_sequence"]):
        filtered = chunk[chunk["trip_id"].isin(active_trip_set)]
        if not filtered.empty:
            chunks.append(filtered)

    if not chunks:
        print("[ERROR] No stop_times matched the selected trips. Check filters.")
        sys.exit(1)

    st_df = pd.concat(chunks, ignore_index=True)
    print(f"    Loaded {len(st_df):,} stop_times entries for selected trips.")

    # 4. Form consecutive stop pairs (edges) along each trip
    print("[*] Generating consecutive stop pairs per trip...")
    st_df.sort_values(by=["trip_id", "stop_sequence"], inplace=True)
    st_df["raw_stop_id"] = st_df["stop_id"].astype(str)
    # Map stop IDs to numeric Long IDs
    st_df["src_id"] = st_df["raw_stop_id"].map(stop_id_map)
    st_df["dst_id"] = st_df.groupby("trip_id")["src_id"].shift(-1)

    # Filter out the final stop of each trip (where dst_id is NaN)
    edges_raw = st_df.dropna(subset=["dst_id"]).copy()
    edges_raw["dst_id"] = edges_raw["dst_id"].astype(np.int64)
    edges_raw["src_id"] = edges_raw["src_id"].astype(np.int64)
    edges_raw["route_id"] = edges_raw["trip_id"].map(active_trip_to_route)

    # 5. Deduplicate (src_id, dst_id, route_id) rows
    print("[*] Deduplicating (src_id, dst_id, route_id) edges...")
    edges_dedup = edges_raw[["src_id", "dst_id", "route_id"]].drop_duplicates().copy()

    # 6. Drop edges referring to missing stops
    valid_vertex_set = set(stops_df["stop_id"])
    edges_valid = edges_dedup[
        edges_dedup["src_id"].isin(valid_vertex_set) & edges_dedup["dst_id"].isin(valid_vertex_set)
    ].copy()

    # Filter stops to keep only those participating in the graph (or all if no filter)
    connected_stops = set(edges_valid["src_id"]).union(set(edges_valid["dst_id"]))
    if max_routes is not None or route_ids is not None:
        final_stops_df = stops_df[stops_df["stop_id"].isin(connected_stops)].copy()
    else:
        final_stops_df = stops_df.copy()

    # 7. Calculate Haversine distance * 1.3 road factor
    print("[*] Computing distances (Haversine * 1.3 road winding factor)...")
    coords_map = dict(zip(stops_df["stop_id"], zip(stops_df["stop_lat"], stops_df["stop_lon"])))

    src_coords = np.array([coords_map[sid] for sid in edges_valid["src_id"]])
    dst_coords = np.array([coords_map[did] for did in edges_valid["dst_id"]])

    straight_line_dist = haversine_vectorized(
        src_coords[:, 0], src_coords[:, 1],
        dst_coords[:, 0], dst_coords[:, 1]
    )
    # Apply 1.3 empirical urban road detour factor
    edges_valid["distance_km"] = np.round(straight_line_dist * 1.3, 4)

    # Ensure minimal positive distance to avoid 0.0 loop edges
    edges_valid["distance_km"] = edges_valid["distance_km"].clip(lower=0.01)

    # 8. Export CSVs
    final_stops = final_stops_df[["stop_id", "stop_name", "stop_lat", "stop_lon"]].rename(
        columns={"stop_lat": "lat", "stop_lon": "lon"}
    )
    final_edges = edges_valid[["src_id", "dst_id", "route_id", "distance_km"]]

    out_stops_path = os.path.join(output_dir, "stops.csv")
    out_edges_path = os.path.join(output_dir, "edges.csv")

    final_stops.to_csv(out_stops_path, index=False)
    final_edges.to_csv(out_edges_path, index=False)

    total_stops = len(final_stops)
    total_edges = len(final_edges)
    total_routes = final_edges["route_id"].nunique()

    print("\n" + "=" * 55)
    print(" PREPROCESSING SUMMARY")
    print("=" * 55)
    print(f" Output stops file : {out_stops_path}")
    print(f" Output edges file : {out_edges_path}")
    print(f" Total Stops       : {total_stops:,}")
    print(f" Total Edges       : {total_edges:,}")
    print(f" Total Routes      : {total_routes:,}")
    print(f" Mean edge distance: {final_edges['distance_km'].mean():.2f} km")
    print(f" Max edge distance : {final_edges['distance_km'].max():.2f} km")
    print("=" * 55)


def main():
    parser = argparse.ArgumentParser(
        description="Convert Delhi GTFS into GraphX-ready stops.csv and edges.csv"
    )
    parser.add_argument(
        "--raw-dir",
        default="gtfs_raw",
        help="Directory containing unzipped GTFS files (default: gtfs_raw)",
    )
    parser.add_argument(
        "--output-dir",
        default="data",
        help="Directory to save stops.csv and edges.csv (default: data)",
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=None,
        help="Subset to first N routes for quick testing on laptop (default: all routes)",
    )
    parser.add_argument(
        "--routes",
        nargs="+",
        type=int,
        default=None,
        help="Specific route IDs to include (e.g., --routes 0 1 2 3)",
    )

    args = parser.parse_args()

    # Step A: Ensure GTFS data is available
    ensure_gtfs_extracted(args.raw_dir)

    # Step B: Run pipeline
    preprocess(
        raw_dir=args.raw_dir,
        output_dir=args.output_dir,
        max_routes=args.max_routes,
        route_ids=args.routes,
    )


if __name__ == "__main__":
    main()
