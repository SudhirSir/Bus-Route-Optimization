#!/usr/bin/env python3
"""
generate_viva_pdf.py
====================
Compiles viva_defense_guide.md into a single, beautifully formatted,
publication-grade PDF document for quick reading and viva exam preparation.
"""

import os
import re
import subprocess
import markdown_it
from pygments import highlight
from pygments.lexers import get_lexer_by_name, TextLexer
from pygments.formatters import HtmlFormatter

WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))
MD_PATH = os.path.join(WORKSPACE_DIR, "viva_defense_guide.md")
HTML_PATH = os.path.join(WORKSPACE_DIR, "viva_defense_guide.html")
PDF_PATH = os.path.join(WORKSPACE_DIR, "INT315_Project_Viva_Defense_Guide.pdf")

def highlight_code(code, lang, attrs):
    try:
        lexer = get_lexer_by_name(lang) if lang else TextLexer()
    except Exception:
        lexer = TextLexer()
    return highlight(code, lexer, HtmlFormatter(nowrap=False, style="friendly"))

def build_pdf():
    with open(MD_PATH, "r", encoding="utf-8") as f:
        md_text = f.read()

    # Setup parser
    md = markdown_it.MarkdownIt("gfm-like", {"linkify": False, "highlight": highlight_code})
    html_body = md.render(md_text)

    formatter = HtmlFormatter(style="friendly")
    pygments_css = formatter.get_style_defs(".highlight")

    full_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>INT315 Capstone Viva Defense Guide</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/contrib/auto-render.min.js"
    onload="renderMathInElement(document.body, {{delimiters: [{{left: '$$', right: '$$', display: true}}, {{left: '$', right: '$', display: false}}]}});">
</script>

<style>
@page {{
    size: A4 portrait;
    margin: 18mm 16mm 20mm 16mm;
    @bottom-center {{
        content: counter(page);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 8.5pt;
        color: #64748b;
    }}
}}

*, *:before, *:after {{
    box-sizing: border-box;
}}

body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 10pt;
    line-height: 1.62;
    color: #1e293b;
    background: #ffffff;
    margin: 0;
    padding: 0;
}}

.doc-header {{
    border-bottom: 2.5px solid #2563eb;
    padding-bottom: 18px;
    margin-bottom: 24px;
}}

.doc-tag {{
    display: inline-block;
    background: #1e3a8a;
    color: #ffffff;
    font-size: 8pt;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    padding: 3px 10px;
    border-radius: 4px;
    margin-bottom: 10px;
}}

.doc-title {{
    font-size: 21pt;
    font-weight: 800;
    color: #0f172a;
    line-height: 1.25;
    margin: 0 0 6px 0;
}}

.doc-sub {{
    font-size: 12pt;
    font-weight: 600;
    color: #2563eb;
    margin: 0 0 14px 0;
}}

.meta-grid {{
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 10px 14px;
}}

.meta-item {{
    font-size: 8pt;
}}

.meta-label {{
    color: #64748b;
    text-transform: uppercase;
    font-weight: 700;
    font-size: 7pt;
    letter-spacing: 0.05em;
}}

.meta-val {{
    color: #0f172a;
    font-weight: 600;
}}

h1 {{ display: none; }}

h2 {{
    font-size: 13pt;
    font-weight: 700;
    color: #0f172a;
    border-left: 4px solid #2563eb;
    padding-left: 10px;
    margin-top: 28px;
    margin-bottom: 12px;
    page-break-after: avoid;
    break-after: avoid;
}}

h3 {{
    font-size: 11pt;
    font-weight: 700;
    color: #1e3a8a;
    margin-top: 18px;
    margin-bottom: 8px;
    page-break-after: avoid;
    break-after: avoid;
}}

p {{
    margin: 0 0 11px 0;
    text-align: justify;
}}

blockquote {{
    background: #eff6ff;
    border-left: 4px solid #3b82f6;
    margin: 14px 0;
    padding: 12px 16px;
    border-radius: 0 6px 6px 0;
    color: #1e3a8a;
    font-size: 10pt;
    font-style: italic;
}}

table {{
    width: 100%;
    border-collapse: collapse;
    margin: 14px 0 18px 0;
    font-size: 8.5pt;
    page-break-inside: avoid;
    break-inside: avoid;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    overflow: hidden;
}}

thead tr {{
    background-color: #1e293b;
    color: #ffffff;
}}

th {{
    padding: 7px 10px;
    text-align: left;
    font-weight: 600;
    border: 1px solid #334155;
}}

td {{
    padding: 6px 10px;
    border: 1px solid #e2e8f0;
    color: #334155;
    vertical-align: middle;
}}

tbody tr:nth-child(even) {{
    background-color: #f8fafc;
}}

pre {{
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-left: 3.5px solid #3b82f6;
    border-radius: 6px;
    padding: 10px 14px;
    margin: 12px 0 16px 0;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 8pt;
    line-height: 1.45;
    color: #1e293b;
    overflow-x: auto;
}}

code {{
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 8.5pt;
    background: #f1f5f9;
    color: #0f172a;
    padding: 1.5px 5px;
    border-radius: 3px;
    border: 1px solid #e2e8f0;
}}

pre code {{
    background: transparent;
    padding: 0;
    border: none;
    font-size: inherit;
}}

{pygments_css}

.katex-display {{
    margin: 10px 0 !important;
    font-size: 10.5pt !important;
}}

hr {{
    border: none;
    border-top: 1px solid #e2e8f0;
    margin: 22px 0;
}}

@media print {{
    body {{
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }}
}}
</style>
</head>
<body>

<header class="doc-header">
  <div class="doc-tag">INT315 — Cluster Computing &bull; Viva Voce Defense Guide</div>
  <div class="doc-title">Project 15: Bus Route Optimization using Apache Spark GraphX</div>
  <div class="doc-sub">Comprehensive Theory, Methodologies, Cluster Architecture &amp; Top 11 Viva Q&amp;A</div>
  
  <div class="meta-grid">
    <div class="meta-item">
      <div class="meta-label">Student Name</div>
      <div class="meta-val">Aman Singh</div>
    </div>
    <div class="meta-item">
      <div class="meta-label">Course Code</div>
      <div class="meta-val">INT315 &bull; Cluster Computing</div>
    </div>
    <div class="meta-item">
      <div class="meta-label">Graph Scale</div>
      <div class="meta-val">8,374 Stops / 8,284 Edges</div>
    </div>
    <div class="meta-item">
      <div class="meta-label">Frameworks</div>
      <div class="meta-val">Spark GraphX &amp; PySpark MLlib</div>
    </div>
  </div>
</header>

<main>
{html_body}
</main>

</body>
</html>
"""

    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(full_html)
    print(f"Generated HTML at: {HTML_PATH}")

    chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    cmd = [
        chrome,
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        "--virtual-time-budget=5000",
        "--run-all-compositor-stages-before-draw",
        "--no-pdf-header-footer",
        f"--print-to-pdf={PDF_PATH}",
        HTML_PATH
    ]
    subprocess.run(cmd, check=True)
    if os.path.exists(PDF_PATH):
        sz_kb = os.path.getsize(PDF_PATH) / 1024
        print(f"Successfully generated PDF: {PDF_PATH} ({sz_kb:.1f} KB)")

if __name__ == "__main__":
    build_pdf()
