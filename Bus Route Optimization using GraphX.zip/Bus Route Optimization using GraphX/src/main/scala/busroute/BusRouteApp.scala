package busroute

import org.apache.spark.sql.SparkSession
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD
import java.io.{File, PrintWriter}
import scala.math._

/**
 * BusRouteApp
 * ===========
 * University Cluster Computing Course Project:
 * "Project 15: Bus Route Optimization using GraphX"
 *
 * This application models a real-world city bus transit network (Delhi DTC/DIMTS)
 * as a directed, weighted graph using Apache Spark GraphX.
 *
 * Pipeline Steps:
 *   1. Load CSV data into Spark DataFrames with inferred schemas.
 *   2. Construct GraphX directed Graph (vertices = stops, edges = bus connections).
 *   3. Compute degrees (in, out, total) and calculate Degree Centrality as a congestion proxy.
 *   4. Calculate distinct routes serving each transit stop.
 *   5. Run Pregel-based Shortest Path (SSSP) weighted by road distance (km) and record execution time.
 *   6. Identify circuitous paths between major hubs and propose a new direct bus link.
 *   7. Re-run Pregel to evaluate before/after improvements (for the pair and sampled network-wide average).
 *   8. Export result tables to CSV for downstream visualization and analytical reporting.
 */
object BusRouteApp {

  // Structure to hold comprehensive path details
  case class PathInfo(
    srcId: VertexId,
    srcName: String,
    dstId: VertexId,
    dstName: String,
    distanceKm: Double,
    hops: Int,
    pathNodeIds: List[VertexId],
    pathNodeNames: List[String]
  )

  /**
   * Vectorized Haversine distance with 1.3 road winding detour factor.
   */
  def haversineRoadKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double = {
    val r = 6371.0 // Earth radius in km
    val dLat = toRadians(lat2 - lat1)
    val dLon = toRadians(lon2 - lon1)
    val a = sin(dLat / 2.0) * sin(dLat / 2.0) +
            cos(toRadians(lat1)) * cos(toRadians(lat2)) *
            sin(dLon / 2.0) * sin(dLon / 2.0)
    val c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a))
    val straightKm = r * c
    straightKm * 1.3 // 1.3x empirical urban road detour factor
  }

  /**
   * Pregel-based Single-Source Shortest Path (SSSP) algorithm with path sequence tracking.
   *
   * Unlike GraphX's built-in ShortestPaths (which only counts unweighted hops),
   * this Pregel implementation minimizes cumulative road distance (Double)
   * while tracking the exact ordered sequence of VertexIds traversed.
   *
   * Each vertex maintains state: (distanceKm: Double, pathList: List[VertexId])
   */
  def runPregelSSSP(
    graph: Graph[(String, Double, Double), (Long, Double)],
    sourceId: VertexId,
    maxIterations: Int = 100
  ): Graph[(Double, List[VertexId]), (Long, Double)] = {

    // 1. Initialize vertices: source vertex gets distance 0.0 and path List(sourceId)
    // All other vertices start with positive infinity and empty path.
    val initialGraph = graph.mapVertices { case (id, _) =>
      if (id == sourceId) (0.0, List(sourceId))
      else (Double.PositiveInfinity, List.empty[VertexId])
    }

    // 2. Initial message sent to all vertices at iteration 0
    val initialMessage = (Double.PositiveInfinity, List.empty[VertexId])

    // 3. Launch Pregel iterative computation
    initialGraph.pregel[(Double, List[VertexId])](
      initialMsg = initialMessage,
      maxIterations = maxIterations,
      activeDirection = EdgeDirection.Out
    )(
      // Vertex Program: Update state if incoming candidate path is shorter
      vprog = (id, currentAttr, candidateMsg) => {
        if (candidateMsg._1 < currentAttr._1) candidateMsg
        else currentAttr
      },

      // Send Message: Propose new candidate distance and extended path along outgoing edges
      sendMsg = triplet => {
        val srcDist = triplet.srcAttr._1
        if (srcDist != Double.PositiveInfinity) {
          val edgeDist = triplet.attr._2
          val candidateDist = srcDist + edgeDist
          // If this path improves the known destination distance, notify the destination vertex
          if (candidateDist < triplet.dstAttr._1) {
            val candidatePath = triplet.srcAttr._2 :+ triplet.dstId
            Iterator((triplet.dstId, (candidateDist, candidatePath)))
          } else {
            Iterator.empty
          }
        } else {
          Iterator.empty
        }
      },

      // Merge Message: In case multiple messages arrive at the same vertex, pick the shortest
      mergeMsg = (msgA, msgB) => if (msgA._1 < msgB._1) msgA else msgB
    )
  }

  /**
   * Extracts formatted PathInfo for a given (src, dst) pair from an SSSP result graph.
   */
  def getPathInfo(
    ssspGraph: Graph[(Double, List[VertexId]), (Long, Double)],
    srcId: VertexId,
    dstId: VertexId,
    namesMap: Map[VertexId, String]
  ): Option[PathInfo] = {
    val dstRecord = ssspGraph.vertices.filter(_._1 == dstId).collect().headOption
    dstRecord.flatMap { case (_, (dist, path)) =>
      if (dist != Double.PositiveInfinity && path.nonEmpty) {
        Some(PathInfo(
          srcId = srcId,
          srcName = namesMap.getOrElse(srcId, s"Stop_$srcId"),
          dstId = dstId,
          dstName = namesMap.getOrElse(dstId, s"Stop_$dstId"),
          distanceKm = dist,
          hops = path.length - 1,
          pathNodeIds = path,
          pathNodeNames = path.map(id => namesMap.getOrElse(id, s"Stop_$id"))
        ))
      } else {
        None
      }
    }
  }

  def main(args: Array[String]): Unit = {
    // Parse command line arguments or use project defaults
    val stopsPath = if (args.length > 0) args(0) else "data/stops.csv"
    val edgesPath = if (args.length > 1) args(1) else "data/edges.csv"
    val outputDir = if (args.length > 2) args(2) else "output"

    println("================================================================================")
    println("        PROJECT 15: BUS ROUTE OPTIMIZATION USING SPARK GRAPHX                   ")
    println("================================================================================")
    println(s" [Config] Stops file  : $stopsPath")
    println(s" [Config] Edges file  : $edgesPath")
    println(s" [Config] Output dir  : $outputDir")

    // Initialize SparkSession
    val spark = SparkSession.builder()
      .appName("BusRouteOptimizationGraphX")
      // Set local master fallback if not already specified by spark-submit
      .config("spark.sql.shuffle.partitions", "4")
      .getOrCreate()

    val sc = spark.sparkContext
    // Set informative log level
    sc.setLogLevel("WARN")

    val startTimeTotal = System.currentTimeMillis()

    // -------------------------------------------------------------------------
    // STEP 1: Load CSV Datasets into Spark DataFrames
    // -------------------------------------------------------------------------
    println("\n>>> Step 1: Loading stops.csv and edges.csv into Spark DataFrames...")
    val stopsDF = spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv(stopsPath)

    val edgesDF = spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv(edgesPath)

    // Convert DataFrames into GraphX RDD representations
    // Vertex attribute: (stop_name, lat, lon)
    val verticesRDD: RDD[(VertexId, (String, Double, Double))] = stopsDF.rdd.map { row =>
      val id = row.getAs[Number]("stop_id").longValue()
      val name = Option(row.getAs[String]("stop_name")).getOrElse(s"Stop_$id").trim
      val lat = row.getAs[Number]("lat").doubleValue()
      val lon = row.getAs[Number]("lon").doubleValue()
      (id, (name, lat, lon))
    }

    // Edge attribute: (route_id, distance_km)
    val edgesRDD: RDD[Edge[(Long, Double)]] = edgesDF.rdd.map { row =>
      val src = row.getAs[Number]("src_id").longValue()
      val dst = row.getAs[Number]("dst_id").longValue()
      val routeId = row.getAs[Number]("route_id").longValue()
      val dist = row.getAs[Number]("distance_km").doubleValue()
      Edge(src, dst, (routeId, dist))
    }

    // -------------------------------------------------------------------------
    // STEP 2: Build Directed Graph & Cache in Memory
    // -------------------------------------------------------------------------
    println(">>> Step 2: Constructing GraphX directed graph and caching...")
    val busGraph = Graph(verticesRDD, edgesRDD).cache()
    val numVertices = busGraph.numVertices
    val numEdges = busGraph.numEdges

    println(s"    [Graph] Total Vertices (Bus Stops) : $numVertices")
    println(s"    [Graph] Total Edges (Direct Links) : $numEdges")

    // Broadcast lookup maps to executors for rapid string/coordinate lookup
    val namesMap = busGraph.vertices.mapValues(_._1).collect().toMap
    val coordsMap = busGraph.vertices.mapValues(v => (v._2, v._3)).collect().toMap

    // -------------------------------------------------------------------------
    // STEP 3 & 4: Degrees, Degree Centrality, and Distinct Route Rankings
    // -------------------------------------------------------------------------
    println("\n>>> Steps 3 & 4: Computing Degrees, Centrality Proxy, and Distinct Routes...")
    val inDegRDD = busGraph.inDegrees
    val outDegRDD = busGraph.outDegrees
    val totDegRDD = busGraph.degrees

    // Distinct routes serving each stop:
    // A stop is served by a route if it is the src or dst of an edge carrying that route_id.
    val stopRoutePairs = busGraph.edges.flatMap { edge =>
      Seq((edge.srcId, edge.attr._1), (edge.dstId, edge.attr._1))
    }.distinct()

    val distinctRoutesRDD = stopRoutePairs.map { case (stopId, _) => (stopId, 1) }
      .reduceByKey(_ + _)

    // Normalization factor: 2 * (N - 1)
    // Degree counts total incident arrows (in + out). Maximum possible in+out arrows is 2*(N-1).
    val normFactor = if (numVertices > 1) 2.0 * (numVertices - 1) else 1.0

    // Join all metrics onto vertices
    val stopMetricsRDD = busGraph.vertices
      .leftOuterJoin(totDegRDD).map { case (id, (attr, degOpt)) => (id, (attr, degOpt.getOrElse(0))) }
      .leftOuterJoin(inDegRDD).map { case (id, ((attr, tot), inOpt)) => (id, (attr, tot, inOpt.getOrElse(0))) }
      .leftOuterJoin(outDegRDD).map { case (id, (((attr, tot, inD), outOpt))) => (id, (attr, tot, inD, outOpt.getOrElse(0))) }
      .leftOuterJoin(distinctRoutesRDD).map { case (id, (((attr, tot, inD, outD)), routeOpt)) =>
        val centrality = tot.toDouble / normFactor
        val distinctRoutes = routeOpt.getOrElse(0)
        (id, attr._1, attr._2, attr._3, inD, outD, tot, centrality, distinctRoutes)
      }.cache()

    // Top 10 Busiest Stops by Degree Centrality
    val top10Centrality = stopMetricsRDD.sortBy(_._8, ascending = false).take(10)
    println("\n================================================================================")
    println(" TOP 10 BUSIEST BUS STOPS BY DEGREE CENTRALITY (CONGESTION PROXY)")
    println("================================================================================")
    println(f"${"Rank"}%-5s ${"Stop ID"}%-9s ${"InDeg"}%-6s ${"OutDeg"}%-7s ${"TotalDeg"}%-9s ${"Centrality"}%-12s ${"Routes"}%-7s ${"Stop Name"}")
    println("-" * 88)
    top10Centrality.zipWithIndex.foreach { case ((id, name, _, _, inD, outD, tot, cent, routes), idx) =>
      println(f"${idx + 1}%-5d $id%-9d $inD%-6d $outD%-7d $tot%-9d $cent%-12.6f $routes%-7d $name")
    }

    // Top 10 Stops by Distinct Routes Served
    val top10Routes = stopMetricsRDD.sortBy(_._9, ascending = false).take(10)
    println("\n================================================================================")
    println(" TOP 10 BUS STOPS BY DISTINCT ROUTES SERVED")
    println("================================================================================")
    println(f"${"Rank"}%-5s ${"Stop ID"}%-9s ${"Routes"}%-7s ${"TotalDeg"}%-9s ${"Centrality"}%-12s ${"Stop Name"}")
    println("-" * 88)
    top10Routes.zipWithIndex.foreach { case ((id, name, _, _, _, _, tot, cent, routes), idx) =>
      println(f"${idx + 1}%-5d $id%-9d $routes%-7d $tot%-9d $cent%-12.6f $name")
    }

    // Export Centrality Metrics to output/centrality.csv
    new File(outputDir).mkdirs()
    val centralityCsvFile = new File(s"$outputDir/centrality.csv")
    val centWriter = new PrintWriter(centralityCsvFile, "UTF-8")
    centWriter.println("stop_id,stop_name,lat,lon,in_degree,out_degree,total_degree,degree_centrality,distinct_routes")
    stopMetricsRDD.collect().sortBy(-_._7).foreach { case (id, name, lat, lon, inD, outD, tot, cent, routes) =>
      centWriter.println(s"""$id,"$name",$lat,$lon,$inD,$outD,$tot,$cent,$routes""")
    }
    centWriter.close()
    println(s"\n[OK] Exported centrality table to: ${centralityCsvFile.getPath}")

    // -------------------------------------------------------------------------
    // STEP 5: Shortest Paths using Pregel (Distance-Weighted)
    // -------------------------------------------------------------------------
    println("\n>>> Step 5: Executing Pregel-based Weighted Shortest Paths...")

    // Select candidate hub vertices for O-D testing
    // We choose Super Bazar/C.P (ID 2186) as central origin, and key hubs as destinations
    val originHubId: VertexId = 2186L // Super Bazar/C.P (Connaught Place)
    val destHubId: VertexId   = 6128L // Dhaula Kuan (Southwest hub)
    val testDestinations = Seq(8284L, 522L, 8330L, 8352L, 6128L)

    println(s"    [Source Hub] : ${namesMap.getOrElse(originHubId, s"Stop_$originHubId")} (ID: $originHubId)")
    println(s"    Running Pregel SSSP on current bus network graph...")

    val pregelStart = System.currentTimeMillis()
    val ssspGraphBefore = runPregelSSSP(busGraph, originHubId).cache()
    // Force evaluation by taking count
    val reachableBeforeCount = ssspGraphBefore.vertices.filter(_._2._1 < Double.PositiveInfinity).count()
    val pregelDurationMs = System.currentTimeMillis() - pregelStart
    println(f"    [Pregel Execution Time] : ${pregelDurationMs / 1000.0}%.3f seconds ($pregelDurationMs ms)")
    println(s"    [Reachability] Reachable stops from source: $reachableBeforeCount / $numVertices")

    // Report OD pairs before optimization
    println("\n--- Shortest Path Results from Super Bazar/C.P (Current Network) ---")
    testDestinations.foreach { dstId =>
      getPathInfo(ssspGraphBefore, originHubId, dstId, namesMap) match {
        case Some(info) =>
          println(f"  -> ${info.dstName}%-30s | Dist: ${info.distanceKm}%6.2f km | Hops: ${info.hops}%2d")
        case None =>
          println(f"  -> ${namesMap.getOrElse(dstId, s"Stop_$dstId")}%-30s | UNREACHABLE")
      }
    }

    // Focus on the high-demand, high-hop bottleneck pair: CP -> Dhaula Kuan
    val targetBeforeOpt = getPathInfo(ssspGraphBefore, originHubId, destHubId, namesMap)
    val targetBefore = targetBeforeOpt.getOrElse {
      throw new RuntimeException(s"Error: No path found between $originHubId and $destHubId in initial graph.")
    }

    println("\n================================================================================")
    println(s" IDENTIFIED BOTTLENECK CORRIDOR: ${targetBefore.srcName} -> ${targetBefore.dstName}")
    println("================================================================================")
    println(f" Current Path Distance : ${targetBefore.distanceKm}%.2f km")
    println(s" Current Transfer Hops : ${targetBefore.hops} hops (${targetBefore.pathNodeIds.size} stops)")
    println(" Current Stop Progression:")
    targetBefore.pathNodeNames.zipWithIndex.foreach { case (name, i) =>
      println(f"   [$i%2d] $name")
    }

    // Export path_before.csv
    val beforeCsvFile = new File(s"$outputDir/path_before.csv")
    val beforeWriter = new PrintWriter(beforeCsvFile, "UTF-8")
    beforeWriter.println("seq_order,stop_id,stop_name,lat,lon,cumulative_dist_km")
    var runningDist = 0.0
    for (i <- targetBefore.pathNodeIds.indices) {
      val nid = targetBefore.pathNodeIds(i)
      val nName = targetBefore.pathNodeNames(i)
      val (lat, lon) = coordsMap.getOrElse(nid, (0.0, 0.0))
      if (i > 0) {
        val prevId = targetBefore.pathNodeIds(i - 1)
        val (pLat, pLon) = coordsMap.getOrElse(prevId, (0.0, 0.0))
        runningDist += haversineRoadKm(pLat, pLon, lat, lon)
      }
      beforeWriter.println(f"""$i,$nid,"$nName",$lat,$lon,$runningDist%.4f""")
    }
    beforeWriter.close()
    println(s"[OK] Exported path_before.csv to: ${beforeCsvFile.getPath}")

    // -------------------------------------------------------------------------
    // STEP 6: Propose ONE New Direct Express Bus Link
    // -------------------------------------------------------------------------
    println("\n>>> Step 6: Proposing New Direct Express Route Link...")
    val (srcLat, srcLon) = coordsMap(originHubId)
    val (dstLat, dstLon) = coordsMap(destHubId)
    val directRoadDist = haversineRoadKm(srcLat, srcLon, dstLat, dstLon)
    val newRouteId = 9999L // Express route identifier

    println(f"    Proposed Link   : ${targetBefore.srcName} (ID $originHubId) <---> ${targetBefore.dstName} (ID $destHubId)")
    println(f"    Estimated Road Distance: $directRoadDist%.2f km (Haversine * 1.3 road factor)")

    // Export new_edge.csv
    val newEdgeCsvFile = new File(s"$outputDir/new_edge.csv")
    val newEdgeWriter = new PrintWriter(newEdgeCsvFile, "UTF-8")
    newEdgeWriter.println("src_id,src_name,dst_id,dst_name,route_id,distance_km")
    newEdgeWriter.println(f"""$originHubId,"${targetBefore.srcName}",$destHubId,"${targetBefore.dstName}",$newRouteId,$directRoadDist%.4f""")
    newEdgeWriter.println(f"""$destHubId,"${targetBefore.dstName}",$originHubId,"${targetBefore.srcName}",$newRouteId,$directRoadDist%.4f""")
    newEdgeWriter.close()
    println(s"[OK] Exported new_edge.csv to: ${newEdgeCsvFile.getPath}")

    // Construct augmented graph with the new bidirectional express link
    val newEdgesRDD = sc.parallelize(Seq(
      Edge(originHubId, destHubId, (newRouteId, directRoadDist)),
      Edge(destHubId, originHubId, (newRouteId, directRoadDist))
    ))
    val optimizedGraph = Graph(busGraph.vertices, busGraph.edges.union(newEdgesRDD)).cache()

    // -------------------------------------------------------------------------
    // STEP 7: Re-run Pregel on Optimized Graph & Compare
    // -------------------------------------------------------------------------
    println("\n>>> Step 7: Re-evaluating Shortest Paths on Optimized Graph...")
    val pregelOptStart = System.currentTimeMillis()
    val ssspGraphAfter = runPregelSSSP(optimizedGraph, originHubId).cache()
    val reachableAfterCount = ssspGraphAfter.vertices.filter(_._2._1 < Double.PositiveInfinity).count()
    val pregelOptDuration = System.currentTimeMillis() - pregelOptStart
    println(f"    [Pregel Execution Time on Optimized Graph] : ${pregelOptDuration / 1000.0}%.3f seconds ($pregelOptDuration ms)")

    val targetAfterOpt = getPathInfo(ssspGraphAfter, originHubId, destHubId, namesMap)
    val targetAfter = targetAfterOpt.getOrElse {
      throw new RuntimeException("Error: No path found in optimized graph.")
    }

    println("\n================================================================================")
    println(s" BEFORE VS AFTER COMPARISON FOR CORRIDOR: ${targetBefore.srcName} -> ${targetBefore.dstName}")
    println("================================================================================")
    val distDiff = targetBefore.distanceKm - targetAfter.distanceKm
    val distPct = (distDiff / targetBefore.distanceKm) * 100.0
    val hopDiff = targetBefore.hops - targetAfter.hops

    println(f" Metric                  | Before              | After               | Improvement")
    println("-" * 80)
    println(f" Distance (km)           | ${targetBefore.distanceKm}%6.2f km           | ${targetAfter.distanceKm}%6.2f km           | -$distDiff%5.2f km (-$distPct%5.1f%%)")
    println(f" Hops (Transfers)        | ${targetBefore.hops}%2d hops             | ${targetAfter.hops}%2d hops              | -$hopDiff%2d hops")
    println(f" Path Stops              | ${targetBefore.pathNodeIds.size}%2d stops            | ${targetAfter.pathNodeIds.size}%2d stops             | -${targetBefore.pathNodeIds.size - targetAfter.pathNodeIds.size}%2d stops")
    println(" New Route Sequence:")
    targetAfter.pathNodeNames.zipWithIndex.foreach { case (name, i) =>
      println(f"   [$i%2d] $name")
    }

    // Export path_after.csv
    val afterCsvFile = new File(s"$outputDir/path_after.csv")
    val afterWriter = new PrintWriter(afterCsvFile, "UTF-8")
    afterWriter.println("seq_order,stop_id,stop_name,lat,lon,cumulative_dist_km")
    var runningDistAfter = 0.0
    for (i <- targetAfter.pathNodeIds.indices) {
      val nid = targetAfter.pathNodeIds(i)
      val nName = targetAfter.pathNodeNames(i)
      val (lat, lon) = coordsMap.getOrElse(nid, (0.0, 0.0))
      if (i > 0) {
        val prevId = targetAfter.pathNodeIds(i - 1)
        val (pLat, pLon) = coordsMap.getOrElse(prevId, (0.0, 0.0))
        runningDistAfter += haversineRoadKm(pLat, pLon, lat, lon)
      }
      afterWriter.println(f"""$i,$nid,"$nName",$lat,$lon,$runningDistAfter%.4f""")
    }
    afterWriter.close()
    println(s"[OK] Exported path_after.csv to: ${afterCsvFile.getPath}")

    // -------------------------------------------------------------------------
    // STEP 8: Sampled Network-Wide Average Shortest Distance Evaluation
    // -------------------------------------------------------------------------
    println("\n>>> Step 8: Network-Wide Average Shortest Distance (Sampled Hub Evaluation)...")
    // Full all-pairs shortest paths on 8,374 nodes is O(V * (V + E)) = 8374 Pregel runs,
    // which would require hours on a single laptop. We evaluate across top 5 representative hubs.
    val sampleHubs = top10Centrality.take(5).map(_._1)
    println(s"    Sampling top ${sampleHubs.length} busiest hubs as origin sources:")
    sampleHubs.foreach(hid => println(s"      - ${namesMap.getOrElse(hid, s"Stop_$hid")} (ID: $hid)"))

    var sumDistBefore = 0.0
    var countPairsBefore = 0L
    var sumDistAfter = 0.0
    var countPairsAfter = 0L

    sampleHubs.foreach { sHubId =>
      val sGraphB = runPregelSSSP(busGraph, sHubId)
      val reachableB = sGraphB.vertices.filter { case (id, (d, _)) => id != sHubId && d < Double.PositiveInfinity }.collect()
      reachableB.foreach { case (_, (d, _)) =>
        sumDistBefore += d
        countPairsBefore += 1
      }

      val sGraphA = runPregelSSSP(optimizedGraph, sHubId)
      val reachableA = sGraphA.vertices.filter { case (id, (d, _)) => id != sHubId && d < Double.PositiveInfinity }.collect()
      reachableA.foreach { case (_, (d, _)) =>
        sumDistAfter += d
        countPairsAfter += 1
      }
    }

    val avgDistBefore = if (countPairsBefore > 0) sumDistBefore / countPairsBefore else 0.0
    val avgDistAfter  = if (countPairsAfter > 0) sumDistAfter / countPairsAfter else 0.0
    val avgDiff = avgDistBefore - avgDistAfter
    val avgPct = if (avgDistBefore > 0) (avgDiff / avgDistBefore) * 100.0 else 0.0

    println("\n================================================================================")
    println(" NETWORK-WIDE AVERAGE SHORTEST DISTANCE (SAMPLED HUB EVALUATION)")
    println("================================================================================")
    println(f" Sample Sources Evaluated : ${sampleHubs.length} major transit hubs")
    println(f" Reachable O-D Pairs      : $countPairsBefore pairs evaluated")
    println(f" Network Avg Dist (Before): $avgDistBefore%6.2f km")
    println(f" Network Avg Dist (After) : $avgDistAfter%6.2f km")
    println(f" Average Network Delta    : -$avgDiff%5.2f km (-$avgPct%5.2f%% overall travel distance reduction)")
    println("================================================================================")

    val totalDuration = (System.currentTimeMillis() - startTimeTotal) / 1000.0
    println(f"\n[DONE] Full pipeline completed in $totalDuration%.2f seconds.")

    spark.stop()
  }
}
