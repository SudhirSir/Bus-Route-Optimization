#!/usr/bin/env python3
"""
viz/plot.py
===========
Visualization script for "Project 15: Bus Route Optimization using GraphX".

Reads data/ and output/ directories and generates:
  1. viz/network.png : Side-by-side NetworkX + Matplotlib publication-grade figure.
     - Left panel: Current transit network with the 25-hop circuitous shortest path in red.
     - Right panel: Optimized network with the proposed direct express link in dashed green
       and the streamlined 1-hop shortest path in green.
     - Node positions = (lon, lat); sizes proportional to degree centrality.
     - Name labels rendered for top ~15 busiest stops for readability.
  2. viz/map.html : Interactive Folium Leaflet web map displaying:
     - Geographic layer with top bus hubs (marker size scaled by degree centrality).
     - Red polyline for the original 18.88 km / 25-hop path with stop popups.
     - Bright green dashed polyline for the proposed 9.57 km direct express corridor.
     - Interactive tooltips, layer control, and analytical summary legend.
"""

import os
import sys
import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import folium
from folium import plugins


def generate_network_plot(
    stops_file: str,
    edges_file: str,
    centrality_file: str,
    path_before_file: str,
    path_after_file: str,
    new_edge_file: str,
    output_png: str = "viz/network.png",
):
    print(f"[*] Generating side-by-side network plot -> '{output_png}'...")
    stops_df = pd.read_csv(stops_file)
    edges_df = pd.read_csv(edges_file)
    cent_df = pd.read_csv(centrality_file)
    p_before_df = pd.read_csv(path_before_file)
    p_after_df = pd.read_csv(path_after_file)
    new_edge_df = pd.read_csv(new_edge_file)

    # Build NetworkX DiGraph
    G = nx.DiGraph()
    for _, r in stops_df.iterrows():
        sid = int(r["stop_id"])
        G.add_node(sid, name=str(r["stop_name"]), lat=float(r["lat"]), lon=float(r["lon"]))

    for _, r in edges_df.iterrows():
        G.add_edge(int(r["src_id"]), int(r["dst_id"]), weight=float(r["distance_km"]))

    # Node positions: (lon, lat)
    pos = {node: (data["lon"], data["lat"]) for node, data in G.nodes(data=True)}

    # Map stop_id to degree and centrality
    deg_map = dict(zip(cent_df["stop_id"], cent_df["total_degree"]))
    name_map = dict(zip(cent_df["stop_id"], cent_df["stop_name"]))

    # Identify top ~15 hubs for labeling
    top_15_hubs = cent_df.head(15)["stop_id"].tolist()

    # Paths as edge lists
    before_nodes = p_before_df["stop_id"].tolist()
    before_edges = list(zip(before_nodes[:-1], before_nodes[1:]))

    after_nodes = p_after_df["stop_id"].tolist()
    after_edges = list(zip(after_nodes[:-1], after_nodes[1:]))

    proposed_edges = list(zip(new_edge_df["src_id"], new_edge_df["dst_id"]))

    # Distance & Hop metrics
    dist_before = p_before_df["cumulative_dist_km"].iloc[-1]
    hops_before = len(before_nodes) - 1
    dist_after = p_after_df["cumulative_dist_km"].iloc[-1]
    hops_after = len(after_nodes) - 1

    # Bounding box for Delhi network
    lons = [p[0] for p in pos.values()]
    lats = [p[1] for p in pos.values()]
    # Focus slightly around Delhi NCT urban core for maximum clarity
    lon_min, lon_max = np.percentile(lons, 1), np.percentile(lons, 99)
    lat_min, lat_max = np.percentile(lats, 1), np.percentile(lats, 99)
    pad_lon = (lon_max - lon_min) * 0.05
    pad_lat = (lat_max - lat_min) * 0.05

    # Figure Setup: 2 panels, high resolution
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 11), facecolor="#0f172a")

    for ax, title, is_after in [
        (ax1, "Current Delhi Bus Network (Before Optimization)", False),
        (ax2, "Optimized Network with Direct Express Corridor (After)", True),
    ]:
        ax.set_facecolor("#1e293b")
        ax.set_title(title, fontsize=15, fontweight="bold", color="#f8fafc", pad=15)
        ax.set_xlim(lon_min - pad_lon, lon_max + pad_lon)
        ax.set_ylim(lat_min - pad_lat, lat_max + pad_lat)
        ax.set_xlabel("Longitude (°E)", fontsize=11, color="#94a3b8")
        ax.set_ylabel("Latitude (°N)", fontsize=11, color="#94a3b8")
        ax.tick_params(colors="#94a3b8", labelsize=9)
        for spine in ax.spines.values():
            spine.set_color("#334155")
        ax.grid(True, linestyle=":", alpha=0.3, color="#475569")

        # 1. Background Network Edges
        # Sample or plot background edges with subtle transparency
        background_edge_sample = list(G.edges())
        if len(background_edge_sample) > 5000:
            # Subsample for crisp plotting performance
            step = len(background_edge_sample) // 4000 + 1
            background_edge_sample = background_edge_sample[::step]

        nx.draw_networkx_edges(
            G,
            pos,
            edgelist=background_edge_sample,
            ax=ax,
            edge_color="#475569",
            alpha=0.25,
            width=0.6,
            arrows=False,
        )

        # 2. Hub Nodes (sized by total degree)
        # Plot top 100 busiest hubs
        top_100_df = cent_df.head(100)
        node_sizes = [max(15, deg_map.get(sid, 1) * 7) for sid in top_100_df["stop_id"]]
        hub_pos = {sid: pos[sid] for sid in top_100_df["stop_id"] if sid in pos}
        nx.draw_networkx_nodes(
            G,
            hub_pos,
            nodelist=list(hub_pos.keys()),
            node_size=node_sizes,
            node_color="#38bdf8",
            alpha=0.6,
            ax=ax,
        )

        # 3. Path Overlays
        if not is_after:
            # LEFT PANEL: Before Path in Vibrant Crimson Red
            nx.draw_networkx_edges(
                G,
                pos,
                edgelist=before_edges,
                ax=ax,
                edge_color="#ef4444",
                width=3.2,
                alpha=0.95,
                arrows=True,
                arrowsize=14,
                arrowstyle="-|>",
            )
            # Nodes on before path
            nx.draw_networkx_nodes(
                G,
                pos,
                nodelist=before_nodes,
                node_size=65,
                node_color="#f87171",
                ax=ax,
            )
            # Origin and Destination highlight
            nx.draw_networkx_nodes(
                G,
                pos,
                nodelist=[before_nodes[0]],
                node_size=200,
                node_color="#fbbf24",
                ax=ax,
            )
            nx.draw_networkx_nodes(
                G,
                pos,
                nodelist=[before_nodes[-1]],
                node_size=200,
                node_color="#e11d48",
                ax=ax,
            )

            # Metric Box
            box_text = (
                f"CORRIDOR METRICS (BEFORE):\n"
                f"• Origin : {name_map.get(before_nodes[0], 'Origin')}\n"
                f"• Dest   : {name_map.get(before_nodes[-1], 'Destination')}\n"
                f"• Distance: {dist_before:.2f} km\n"
                f"• Transfers: {hops_before} hops (Circuitous Detour)"
            )
            ax.text(
                0.03,
                0.95,
                box_text,
                transform=ax.transAxes,
                fontsize=10.5,
                verticalalignment="top",
                bbox=dict(
                    boxstyle="round,pad=0.6",
                    facecolor="#0f172a",
                    edgecolor="#ef4444",
                    linewidth=1.8,
                    alpha=0.9,
                ),
                color="#f8fafc",
                family="monospace",
            )
        else:
            # RIGHT PANEL: After Path in Emerald Green + Proposed Link
            # Draw Proposed Direct Link as Thick Dashed Green Line
            nx.draw_networkx_edges(
                G,
                pos,
                edgelist=proposed_edges,
                ax=ax,
                edge_color="#10b981",
                width=4.0,
                style="dashed",
                alpha=1.0,
                arrows=True,
                arrowsize=18,
                arrowstyle="-|>",
            )
            # Optimized Path
            nx.draw_networkx_edges(
                G,
                pos,
                edgelist=after_edges,
                ax=ax,
                edge_color="#34d399",
                width=3.0,
                alpha=0.9,
                arrows=False,
            )
            # Origin and Destination highlight
            nx.draw_networkx_nodes(
                G,
                pos,
                nodelist=[after_nodes[0]],
                node_size=220,
                node_color="#fbbf24",
                ax=ax,
            )
            nx.draw_networkx_nodes(
                G,
                pos,
                nodelist=[after_nodes[-1]],
                node_size=220,
                node_color="#10b981",
                ax=ax,
            )

            # Metric Box with Improvement
            dist_reduction = dist_before - dist_after
            pct_reduction = (dist_reduction / dist_before) * 100.0
            box_text = (
                f"CORRIDOR METRICS (AFTER):\n"
                f"• Proposed Link : Direct Express Line\n"
                f"• Distance      : {dist_after:.2f} km (▼ {dist_reduction:.2f} km, -{pct_reduction:.1f}%)\n"
                f"• Transfers     : {hops_after} hop (▼ {hops_before - hops_after} fewer hops)\n"
                f"• Network Sample Avg: 23.30 km → 23.22 km"
            )
            ax.text(
                0.03,
                0.95,
                box_text,
                transform=ax.transAxes,
                fontsize=10.5,
                verticalalignment="top",
                bbox=dict(
                    boxstyle="round,pad=0.6",
                    facecolor="#0f172a",
                    edgecolor="#10b981",
                    linewidth=1.8,
                    alpha=0.9,
                ),
                color="#f8fafc",
                family="monospace",
            )

        # 4. Labels for Top Hubs
        labels = {}
        for hid in top_15_hubs[:12]:
            clean_name = name_map.get(hid, f"Stop {hid}").split("/")[0][:18]
            labels[hid] = clean_name

        # Include Origin and Destination explicitly
        labels[before_nodes[0]] = "★ " + name_map.get(before_nodes[0], "").split("/")[0]
        labels[before_nodes[-1]] = "★ " + name_map.get(before_nodes[-1], "").split("/")[0]

        nx.draw_networkx_labels(
            G,
            pos,
            labels=labels,
            font_size=8.5,
            font_color="#f1f5f9",
            font_weight="bold",
            bbox=dict(
                boxstyle="round,pad=0.25",
                facecolor="#1e293b",
                edgecolor="#475569",
                alpha=0.85,
            ),
            ax=ax,
        )

    # Global Legend at Bottom
    legend_elements = [
        mlines.Line2D([], [], color="#475569", lw=1.2, label="Bus Network Connections"),
        mlines.Line2D([], [], color="#38bdf8", marker="o", ls="", ms=7, label="Transit Hubs (Scaled by Degree)"),
        mlines.Line2D([], [], color="#ef4444", lw=3.0, label=f"Path Before ({dist_before:.2f} km, {hops_before} hops)"),
        mlines.Line2D([], [], color="#10b981", lw=3.5, ls="--", label=f"Proposed Link & Path After ({dist_after:.2f} km, {hops_after} hop)"),
        mlines.Line2D([], [], color="#fbbf24", marker="o", ls="", ms=10, label="Origin (Super Bazar / Connaught Place)"),
        mlines.Line2D([], [], color="#e11d48", marker="o", ls="", ms=10, label="Destination (Dhaula Kuan Interchange)"),
    ]
    fig.legend(
        handles=legend_elements,
        loc="lower center",
        ncol=3,
        fontsize=10.5,
        frameon=True,
        facecolor="#0f172a",
        edgecolor="#334155",
        labelcolor="#e2e8f0",
        bbox_to_anchor=(0.5, 0.015),
    )

    plt.tight_layout(rect=[0, 0.07, 1, 0.98])
    os.makedirs(os.path.dirname(output_png), exist_ok=True)
    plt.savefig(output_png, dpi=300, facecolor=fig.get_facecolor(), edgecolor="none")
    plt.close()
    print(f"[OK] Saved high-resolution network figure: {output_png}")


def generate_interactive_map(
    stops_file: str,
    centrality_file: str,
    path_before_file: str,
    path_after_file: str,
    new_edge_file: str,
    output_html: str = "viz/map.html",
):
    print(f"[*] Generating interactive Folium map -> '{output_html}'...")
    stops_df = pd.read_csv(stops_file)
    cent_df = pd.read_csv(centrality_file)
    p_before_df = pd.read_csv(path_before_file)
    p_after_df = pd.read_csv(path_after_file)
    new_edge_df = pd.read_csv(new_edge_file)

    # Center map on Delhi urban core (Connaught Place / Parliament area)
    delhi_center = [28.6250, 77.2100]
    m = folium.Map(
        location=delhi_center,
        zoom_start=12,
        tiles=None,
        control_scale=True,
    )

    # Reliable, high-definition basemaps that require no API keys and never block
    folium.TileLayer(
        tiles="https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}",
        attr="Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ, TomTom, USGS",
        name="Topographic Street Map (Default)",
        overlay=False,
        control=True,
    ).add_to(m)

    folium.TileLayer(
        tiles="https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
        attr="Tiles &copy; Esri &mdash; Source: Esri, DeLorme, NAVTEQ, USGS",
        name="Detailed City Map (Esri)",
        overlay=False,
        control=True,
    ).add_to(m)

    # Feature Groups for toggling layers
    fg_hubs = folium.FeatureGroup(name="Top Transit Congestion Hubs", show=True)
    fg_path_before = folium.FeatureGroup(name="Shortest Path Before (18.88 km / 25 hops)", show=True)
    fg_path_after = folium.FeatureGroup(name="Shortest Path After (9.57 km / 1 hop)", show=True)
    fg_proposed_link = folium.FeatureGroup(name="Proposed Express Corridor (Direct)", show=True)

    # 1. Add Top 25 Transit Hubs
    top_25 = cent_df.head(25)
    for _, row in top_25.iterrows():
        sid = int(row["stop_id"])
        name = row["stop_name"]
        lat = float(row["lat"])
        lon = float(row["lon"])
        deg = int(row["total_degree"])
        cent = float(row["degree_centrality"])
        routes = int(row["distinct_routes"])

        radius = max(6, int(deg * 0.45))
        popup_html = f"""
        <div style="font-family: Arial, sans-serif; font-size: 12px; width: 220px;">
            <h4 style="margin: 0 0 6px 0; color: #2563eb;">{name}</h4>
            <b>Stop ID:</b> {sid}<br/>
            <b>Total Degree:</b> {deg} (In: {int(row['in_degree'])}, Out: {int(row['out_degree'])})<br/>
            <b>Degree Centrality:</b> {cent:.6f}<br/>
            <b>Distinct Bus Routes:</b> {routes}<br/>
        </div>
        """
        folium.CircleMarker(
            location=[lat, lon],
            radius=radius,
            color="#38bdf8",
            weight=2,
            fill=True,
            fill_color="#0284c7",
            fill_opacity=0.7,
            popup=folium.Popup(popup_html, max_width=250),
            tooltip=f"{name} (Degree: {deg})",
        ).add_to(fg_hubs)

    # 2. Add Path Before (Red Line + Node Markers)
    coords_before = [[r["lat"], r["lon"]] for _, r in p_before_df.iterrows()]
    folium.PolyLine(
        locations=coords_before,
        color="#ef4444",
        weight=5,
        opacity=0.85,
        tooltip="Original 25-hop Path (18.88 km)",
    ).add_to(fg_path_before)

    for idx, r in p_before_df.iterrows():
        order = int(r["seq_order"])
        sname = r["stop_name"]
        cdist = float(r["cumulative_dist_km"])
        folium.CircleMarker(
            location=[r["lat"], r["lon"]],
            radius=4,
            color="#ef4444",
            fill=True,
            fill_color="#fca5a5",
            fill_opacity=0.9,
            tooltip=f"[{order}] {sname} ({cdist:.2f} km)",
        ).add_to(fg_path_before)

    # 3. Add Path After (Green Line)
    coords_after = [[r["lat"], r["lon"]] for _, r in p_after_df.iterrows()]
    folium.PolyLine(
        locations=coords_after,
        color="#10b981",
        weight=6,
        opacity=0.95,
        tooltip="Optimized Direct Path (9.57 km)",
    ).add_to(fg_path_after)

    # 4. Add Proposed Express Corridor (Dashed Green line)
    folium.PolyLine(
        locations=coords_after,
        color="#34d399",
        weight=7,
        dash_array="10, 10",
        opacity=1.0,
        tooltip="Proposed Direct Express Corridor Link",
    ).add_to(fg_proposed_link)

    # Special Origin and Destination Markers
    origin_row = p_before_df.iloc[0]
    dest_row = p_before_df.iloc[-1]

    folium.Marker(
        location=[origin_row["lat"], origin_row["lon"]],
        popup=f"<b>ORIGIN HUB:</b> {origin_row['stop_name']} (Connaught Place)",
        icon=folium.Icon(color="orange", icon="play", prefix="fa"),
    ).add_to(m)

    folium.Marker(
        location=[dest_row["lat"], dest_row["lon"]],
        popup=f"<b>DESTINATION HUB:</b> {dest_row['stop_name']} (Dhaula Kuan)",
        icon=folium.Icon(color="green", icon="flag-checkered", prefix="fa"),
    ).add_to(m)

    # Add all feature groups to map
    fg_hubs.add_to(m)
    fg_path_before.add_to(m)
    fg_path_after.add_to(m)
    fg_proposed_link.add_to(m)

    # Layer control
    folium.LayerControl(collapsed=False).add_to(m)

    # Floating Info Box (Summary Dashboard)
    summary_html = f"""
    <div style="
        position: fixed;
        bottom: 30px;
        left: 30px;
        width: 320px;
        z-index: 9999;
        background-color: rgba(15, 23, 42, 0.92);
        color: #f8fafc;
        padding: 14px 18px;
        border-radius: 8px;
        border: 1px solid #334155;
        font-family: Arial, sans-serif;
        box-shadow: 0 4px 12px rgba(0,0,0,0.5);
        font-size: 12px;
    ">
        <h4 style="margin: 0 0 8px 0; color: #38bdf8; font-size: 14px;">Delhi Bus Route Optimization</h4>
        <b>Corridor:</b> Connaught Place → Dhaula Kuan<br/>
        <div style="margin: 6px 0; border-top: 1px solid #334155; padding-top: 6px;">
            <span style="color: #ef4444; font-weight: bold;">■ Current Path:</span> 18.88 km | 25 hops<br/>
            <span style="color: #10b981; font-weight: bold;">■ Optimized Path:</span> 9.57 km | 1 hop<br/>
            <span style="color: #fbbf24; font-weight: bold;">★ Improvement:</span> -9.32 km (-49.3%), -24 hops
        </div>
        <div style="margin-top: 6px; font-size: 11px; color: #94a3b8;">
            Analyzed using Apache Spark GraphX Pregel
        </div>
    </div>
    """
    m.get_root().html.add_child(folium.Element(summary_html))

    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    m.save(output_html)
    print(f"[OK] Saved interactive HTML map: {output_html}")


def main():
    stops_file = "data/stops.csv"
    edges_file = "data/edges.csv"
    cent_file = "output/centrality.csv"
    p_before = "output/path_before.csv"
    p_after = "output/path_after.csv"
    new_edge = "output/new_edge.csv"

    for req in [stops_file, edges_file, cent_file, p_before, p_after, new_edge]:
        if not os.path.exists(req):
            print(f"[ERROR] Required input file '{req}' does not exist.")
            print("Please run Spark/GraphX program first to generate outputs.")
            sys.exit(1)

    generate_network_plot(
        stops_file=stops_file,
        edges_file=edges_file,
        centrality_file=cent_file,
        path_before_file=p_before,
        path_after_file=p_after,
        new_edge_file=new_edge,
        output_png="viz/network.png",
    )

    generate_interactive_map(
        stops_file=stops_file,
        centrality_file=cent_file,
        path_before_file=p_before,
        path_after_file=p_after,
        new_edge_file=new_edge,
        output_html="viz/map.html",
    )


if __name__ == "__main__":
    main()
